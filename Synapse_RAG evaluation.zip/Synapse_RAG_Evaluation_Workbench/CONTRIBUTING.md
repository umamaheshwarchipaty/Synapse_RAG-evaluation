# Contributing

1. Install Node.js 20+ and npm.
2. Run `npm install`.
3. Create a focused change and add/update deterministic tests for metric behavior.
4. Run `npm run lint`, `npm test`, and `npm run build` before submitting.
5. Document metric assumptions and limitations; do not upgrade a heuristic into a semantic correctness claim without evidence.

Please do not add API keys, real customer datasets, or credentials to source control.
