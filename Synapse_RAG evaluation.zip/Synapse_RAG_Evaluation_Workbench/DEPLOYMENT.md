# Deployment and OpenAI configuration

Synapse remains usable without an OpenAI key. The deterministic evaluator runs in the browser and does not call OpenAI. Optional AI features use same-origin Vercel Functions in `api/`; the browser never receives the API key.

## Local setup

1. Install Node.js 20+ and npm 10+.
2. Install dependencies: `npm install` (commit the resulting lockfile for reproducible installs; use `npm ci` after a lockfile exists).
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY` and `SYNAPSE_ACCESS_TOKEN` privately. Optionally set `OPENAI_MODEL` (default: `gpt-4.1-mini`). Never commit `.env` or put the key in a `VITE_` variable.
4. Install or invoke Vercel CLI and run `npx vercel dev` from the project directory. This serves both the Vite frontend and `/api/*` functions locally. Plain `npm run dev` starts Vite only, so API requests will not be served by it.
5. Open the local URL printed by Vercel CLI. If the key is missing, AI requests return a clear configuration error; normal deterministic evaluation remains available.

The API uses the OpenAI Responses API with structured JSON output. `OPENAI_MODEL` selects the model. The benchmark generator sends the supplied source passages to OpenAI. The optional LLM judge sends the selected case's question, answer, reference answer, and retrieved contexts. Only use content you are allowed to send to the configured provider.

## Vercel environment variables

1. Open your Vercel project → **Settings → Environment Variables**.
2. Add `OPENAI_API_KEY` with your secret key as the value. Select the environments where it should be available (Development, Preview, Production as appropriate).
3. Add `SYNAPSE_ACCESS_TOKEN` (random, 24+ characters). The AI endpoints reject every request without it.
3. Add `OPENAI_MODEL` with a supported model name, or omit it to use `gpt-4.1-mini`.
4. Save and redeploy after changing environment variables.
5. In the deployed site, open **AI Benchmark Generator** and generate candidates; then inspect one case and use **Judge this answer** to test the optional judge.

Do not expose the key through `VITE_OPENAI_API_KEY`, frontend source, localStorage, public logs, or API responses. `.env` is ignored by Git. `.env.example` contains placeholder values only. The server never logs request bodies, keys, or provider response bodies.

## API safeguards and limits

- `POST /api/generate-benchmark`: 1–20 unique source passages, max 8,000 characters each, 40,000 total source characters, 1–8 candidates, 50 KB serialized request limit.
- `POST /api/judge-answer`: one question and answer, up to 10 contexts and 25,000 total context characters.
- Both endpoints validate request shapes and output schemas, reject evidence IDs that do not match supplied context IDs, set `Cache-Control: no-store`, and return sanitized provider errors. Provider rate limits are mapped to HTTP 429. A best-effort in-memory per-instance rate limit is included; it is not a replacement for a durable distributed rate limiter.
- The judge is advisory, not calibrated. It is not added to deterministic run metrics and does not constitute proof of semantic truth.
- Avoid sending confidential or regulated data unless your organization's policies permit it.

## Vercel deployment

Keep the Vite build command `npm run build` and output directory `dist`. Vercel detects the `api/` serverless functions from the project root. Deploy and verify the API endpoints yourself; this repository authoring session did not deploy the site or test live API connectivity.

## Authenticated synchronous evaluation webhook (Synapse 2.1)

Set `SYNAPSE_WEBHOOK_SECRET` in Vercel Project Settings → Environment Variables (server-side only; use a random value at least 24 characters long). The `POST /api/evaluate-webhook` endpoint requires `Authorization: Bearer <secret>`. Send JSON containing `dataset` (1–100 cases), `config`, optional `gates` and optional `event_id` / `Idempotency-Key`. The payload limit is 100 KB. `retrieval`, `correctness`, and `citations` gate values are minimums from 0 to 1; `unsupported` is a maximum failure rate. Missing metrics block the relevant gate. The response includes evaluation status, dataset fingerprint, configuration, metric summaries, gate results, and bounded findings.

This endpoint runs synchronously and returns its report in the response. It does not provide durable job storage, cross-instance idempotency, scheduling, or external notifications. No GitHub or Slack integration is configured by this code alone. Never send the webhook secret from browser-side code.

## Security hardening (applied)

- **Access control:** `/api/generate-benchmark` and `/api/judge-answer` require the `x-synapse-access-token` header to match `SYNAPSE_ACCESS_TOKEN`. They fail closed (503) if it is unset or shorter than 24 characters. Enter the token in the AI access token field in the app; it is kept in `sessionStorage` for the tab only.
- **Spend limits:** each OpenAI request sets `max_output_tokens` (4,000 benchmark / 1,200 judge) and input sizes are capped. These do not replace a billing limit.
- **Rate limiting:** all three API routes use a best-effort in-memory limiter (per instance) plus a tighter limit on failed authentication. This is not durable across serverless instances.
- **Security headers:** `vercel.json` sets CSP, frame blocking, nosniff, referrer policy, HSTS and permissions policy for the frontend. The CSP allows Google Fonts because `styles.css` imports it. Verify the deployed app after any change to scripts, fonts or embeds.
- **Webhook:** failed-auth throttling, deeper payload validation, and generic error messages.

## Manual steps you must still do

1. **OpenAI dashboard:** set a monthly budget / usage limit on the project that owns the key.
2. **Vercel Firewall:** add a rate-limit rule for `/api/*` for a durable, cross-instance limit.
3. **Preview deployments:** scope `OPENAI_API_KEY` and `SYNAPSE_ACCESS_TOKEN` to Production only, or enable Deployment Protection (Vercel Authentication) for Previews.
4. **Lockfile:** run `npm install` once and commit `package-lock.json`; CI then uses `npm ci` automatically.
5. **Secrets history:** run `gitleaks detect` (or `git log -p -S"sk-"`) on the real repository; rotate any key that ever appeared in a commit.
6. Run `npm audit` and update dependencies as advisories appear.
