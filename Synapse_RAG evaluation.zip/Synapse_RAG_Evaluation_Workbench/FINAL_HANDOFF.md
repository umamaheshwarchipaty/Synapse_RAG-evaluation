# Synapse 2.0 — Final Handoff

## Deliverable

React 19 + TypeScript + Vite source ZIP preserving the existing application architecture. No Vercel deployment or browser end-to-end test was performed.

## Implemented in this pass

- Strict JSON/JSONL/CSV dataset parsing: malformed rows, duplicate/empty headers, invalid nested context/citation/evidence fields, malformed CSV quoting, and mismatched CSV row widths are rejected with actionable errors. Plain-text context cells in CSV are supported.
- Dataset quality summary reports context totals and empty context text in addition to reference/relevance coverage and invalid references.
- A required missing citation remains a policy finding even if the citation metric is not selected; its citation score remains unavailable rather than being calculated against a disabled metric.
- Exported pure helpers for dataset fingerprints, run-configuration compatibility, and isolated single-case counterfactual evaluation.
- Added Counterfactual Lab UI: changes retrieval cutoff for a selected case, displays before/after metric and finding differences, and does not modify saved runs. It does not rerun a retriever or regenerate answers.
- Added feedback counts by finding category for the selected run; feedback is scoped to run and finding and is not described as calibration.
- Added safe handling for malformed saved collection/theme data and a notice when localStorage persistence fails.
- Added `npm run typecheck` and updated README, feature audit, implementation plan, test report, and demo guide.

## Verification truth

- Strict standalone type-check of core modules: **PASS**. Strict standalone type-check of `server/openai.ts` and both API handlers: **PASS**.
- TypeScript/TSX syntax transpilation of 10 source files: **PASS**, zero syntax diagnostics.
- Direct Node smoke assertions: **PASS**, 29 assertions for the existing deterministic core and 10 assertions for the OpenAI endpoint handlers using mocked responses.
- `npm install`: **BLOCKED**, registry DNS `EAI_AGAIN` for `registry.npmjs.org/@types%2freact`.
- `npm test -- --run`: **BLOCKED**, `vitest: not found` (exit 127).
- `npm run lint`: **BLOCKED**, React/JSX declarations missing (exit 2).
- `npx --no-install tsc --noEmit`: **BLOCKED** by the same missing declarations (exit 2).
- `npm run build`: **BLOCKED** during TypeScript build (exit 1); production bundle not produced.
- Browser E2E and Vercel deployment: **NOT PERFORMED**; the user will do these.

## Dependency and setup limitation

No `package-lock.json` was supplied and no valid lockfile could be generated without registry metadata. Once internet/npm registry resolution works, run `npm install`, commit the generated lockfile, then use `npm ci` on clean machines. No API key is required for deterministic evaluation. Optional AI features require a private server-side `OPENAI_API_KEY` and `OPENAI_MODEL` as documented in `DEPLOYMENT.md`.

## Known limitations

- No external retriever/generator adapter, trace ingestion, secure backend, authentication, or server database. The optional OpenAI judge is advisory, not calibrated.
- Lexical F1 and grounding checks are heuristic signals, not factual verification or semantic entailment.
- Counterfactual Lab re-scores existing ordered passages with a different cutoff; it does not rerun retrieval or generation.
- localStorage is per browser/device and can fail or be cleared; export important runs.
- Full automated tests and production build remain unverified until dependencies install successfully.

## Next commands

```bash
npm install
npm run typecheck
npm run lint
npm test -- --run
npm run build
npm run dev
```

Then complete the browser checklist in `docs/DEMO_GUIDE.md` and deploy through Vercel yourself.


## OpenAI API integration

- `POST /api/generate-benchmark` generates validated candidate questions, reference answers, and source evidence IDs. Users select candidates before importing.
- `POST /api/judge-answer` performs an optional, advisory semantic answer/evidence judgment from the case inspector. It is not a calibrated metric.
- Both endpoints read `OPENAI_API_KEY` and optional `OPENAI_MODEL` only in server-side code. No key is embedded in frontend assets or persisted in browser storage.
- Local AI testing requires `npx vercel dev` and a private `.env`. The deterministic evaluator works without any key.
- No live API request or Vercel deployment was performed. See `TEST_REPORT.md` for actual verification.


## Synapse 2.1 handoff

The synthetic testing lab now supports seven strategy choices, difficulty/count, evidence-ID validation, abstention cases, provenance, edit/approve/reject, candidate JSON export, and approved-only import. The new authenticated `POST /api/evaluate-webhook` returns a synchronous deterministic report and evaluates regression gates. Configure `SYNAPSE_WEBHOOK_SECRET` server-side for that endpoint. Reports/jobs and idempotency are not durably stored; no notifications or external CI provider are configured. Remove any local `.env` from archives and keep secrets in local ignored `.env` or Vercel environment settings only.
