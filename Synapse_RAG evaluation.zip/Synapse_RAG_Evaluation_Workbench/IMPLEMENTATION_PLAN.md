# Synapse 2.0 — Implementation Plan and Remaining Gaps

## Repository and scope

- **Stack:** React 19, TypeScript, Vite, plain CSS, browser `localStorage`, Vitest. The app is local-first and does not require a server for its current deterministic evaluator.
- **Evaluation methods:** Precision@k when relevance labels are complete; expected-evidence ID coverage when supplied; unique-token F1 against reference answers; citation ID resolution; and a lexical grounding heuristic.
- **Important limitation:** these checks do not establish semantic entailment, factual truth, or causal improvement. There is no external RAG pipeline adapter. An optional advisory LLM judge is now implemented through a server-side OpenAI endpoint, separately from deterministic metrics.

## Completed implementation

1. Evaluator honors selected metrics, validates configuration and data IDs, treats missing reference/partial relevance labels as unavailable, and uses exact evidence IDs.
2. Structured findings include category, severity, detection basis, method, evidence IDs, and next investigation. Finding feedback is run-scoped and locally persisted.
3. Dataset import supports JSON, JSONL, and CSV with pre-import preview, strict field/shape validation, duplicate-ID checks, invalid reference warnings, coverage summary, and empty context text warnings.
4. Four built-in presets (Quick Check, Retrieval Audit, Citation Audit, Regression Test) set real evaluator options.
5. Saved runs carry a stable dataset content fingerprint. Pure helpers compare dataset/config compatibility.
6. Analytics derives metrics/findings and feedback counts from the selected saved run. It does not claim calibration.
7. Counterfactual Lab re-scores one selected case with a different retrieval cutoff, displays before/after scores and findings, and does not mutate saved runs or claim to rerun retrieval/generation.
8. Local rules-based assistant answers supported metric/dataset/run/case questions and admits when it lacks information.
9. JSON/CSV/Markdown export, local persistence, themes, and static Workflow Explorer remain in the existing app. Storage errors surface a notice.
10. Updated `README.md`, `FEATURE_AUDIT.md`, `TEST_REPORT.md`, `docs/DEMO_GUIDE.md`, and `FINAL_HANDOFF.md` document functionality and limitations.

## Verification results

- Strict standalone TypeScript check of `src/types.ts`, `src/lib/evaluator.ts`, `src/lib/io.ts`, and `src/lib/assistant.ts`: **PASS**.
- TypeScript/TSX syntax transpilation: **PASS**, 10 files and zero syntax diagnostics.
- Direct Node runtime smoke checks: **PASS**, 29 assertions.
- npm install: **BLOCKED**, registry DNS `EAI_AGAIN` resolving `registry.npmjs.org/@types%2freact`.
- `npm test -- --run`: **BLOCKED**, exit 127 (`vitest: not found`).
- `npm run lint` and `npm run typecheck`: **BLOCKED**, exit 2 due missing React/JSX declarations.
- `npm run build`: **BLOCKED**, exit 1 during TypeScript build; Vite bundling was not reached.
- Browser E2E and Vercel deployment: not performed, as requested.

See `TEST_REPORT.md` for the exact commands and statuses.

## Genuine remaining gaps, in priority order

1. Restore npm registry access; run `npm install`, commit the generated lockfile, then run `npm run typecheck`, `npm run lint`, `npm test -- --run`, and `npm run build`. No lockfile was supplied, and one could not be generated without registry resolution.
2. Complete browser testing of welcome/sample evaluation, import preview, evidence navigation, feedback persistence, Counterfactual Lab, comparisons, reports, and responsive layouts.
3. User-defined saved presets and a versioned evaluation-config import/export workflow are not implemented.
4. No independently labeled benchmark/reliability workflow exists; do not calculate calibration, precision/recall, or agreement until adequate labeled observations and definitions are available.
5. External trace ingestion, retriever/generator integration, authentication, backend persistence, CLI/CI regression threshold gate, and cost/token/latency instrumentation are not implemented. The optional server-side LLM judge is advisory and not calibrated.

## Deployment responsibility

The user will perform browser end-to-end testing and Vercel deployment. Do not describe the application as production-built or deployed until those steps succeed.


## OpenAI integration update

Completed server-side Vercel endpoints for benchmark generation and optional answer judging; structured outputs and evidence IDs are validated, client review is required before dataset import, and deterministic evaluation remains independent of provider configuration. Remaining: user must configure the key privately, run live smoke tests, and deploy. Full dependency-backed checks depend on npm registry access.


## OpenAI integration completed

- Added `POST /api/generate-benchmark` with request limits, structured output, and evidence ID validation.
- Added candidate review and selection in `src/components/AIBenchmarkGenerator.tsx` before dataset import.
- Added `POST /api/judge-answer` and case-inspector UI for optional advisory semantic review.
- Added mocked unit tests in `server/openai.test.ts`, private environment setup documentation, and server-only key handling.
- Live API, browser tests, and deployment remain user-run tasks.


## Synapse 2.1 completion pass

- Implemented the synthetic testing strategy selector, difficulty/count controls, structured candidate metadata, abstention behavior, strict evidence ID validation, editable review cards, explicit approval/rejection, and JSON export. Only approved candidates are imported.
- Implemented `POST /api/evaluate-webhook`: bearer-authenticated synchronous deterministic evaluation, input/payload validation, dataset fingerprint, metric summary, findings, configurable regression gates, and best-effort idempotency.
- Remaining: durable job/run storage, distributed idempotency/rate limiting, notification destination setup, true RAG retriever/model integration, and live provider verification.
