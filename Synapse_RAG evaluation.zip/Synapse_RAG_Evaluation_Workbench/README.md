# Synapse — RAG Evaluation Workbench

Evaluate your RAG pipeline with evidence, not guesswork. Synapse is a developer-focused, local-first evaluation workbench for inspecting retrieval relevance, answer similarity, citation ID validity, and heuristic unsupported-answer signals. It includes repeatable saved runs, case-level evidence inspection, run comparisons, and exportable reports.

> **Official hackathon problem statement**
>
> “A RAG demo may sound convincing while retrieving the wrong passages or generating unsupported answers. A repeatable evaluation workbench helps teams compare changes using evidence rather than subjective impressions. Build a reusable evaluation harness for RAG systems measuring retrieval relevance, answer correctness, citation accuracy, and unsupported answers.”

## Important scope disclosure

The current implementation is a real, deterministic baseline—not a semantic RAG judge. Token-overlap F1 is a lexical similarity signal, not proof of factual correctness. Citation ID resolution does not prove semantic claim support. Unsupported-answer detection is a heuristic. Optional server-side OpenAI benchmark generation and LLM judging are available through Vercel Functions when configured; the deterministic evaluator remains a separate baseline. PDF ingestion, backend database, authentication, and hosted deployment are not configured. The app works without credentials and keeps data in browser `localStorage`.

## Features

- Light, responsive dashboard and navigation across Overview, AI Benchmark Generator, Datasets, Run Evaluation, Evaluation Results, Analytics, Compare Runs, Reports, Assistant, Counterfactual Lab, Workflow Explorer, Settings, and About / Team.
- Built-in fictional shipment reimbursement dataset; all seeded results are clearly identified as illustrative sample data.
- Import JSON, JSONL, and CSV (2 MB maximum) with a pre-import case preview, duplicate-ID checks, reference/relevance coverage, expected-evidence and citation warnings; edit cases and export datasets as JSON.
- Deterministic evaluation of retrieval relevance (Precision@k when labels exist; expected-evidence coverage otherwise), answer token F1, citation ID resolution, and a lexical grounding heuristic.
- Evidence-linked case inspector with answer/reference, retrieved passages, citation IDs, structured diagnostic findings, trigger basis, linked evidence IDs, next investigations, and locally persisted finding feedback.
- Save/reload runs locally; compare aggregate and per-case metric changes, detect dataset/configuration incompatibilities, and investigate failure-state changes.
- Counterfactual Lab: re-score one selected case with a different retrieval cutoff, compare before/after metrics and findings, and preserve saved runs. This does not rerun a retriever or regenerate an answer.
- Workflow Explorer documents the actual local flow from dataset import through deterministic evaluation, saved runs, analytics, comparison, and export.
- Export real run results as JSON, CSV, and Markdown reports.
- Analytics page with saved-run selection, metric summaries, finding-category counts, severity/category filters, and case navigation.
- Optional OpenAI synthetic testing lab: seven challenge strategies, difficulty/count controls, schema and evidence-ID validation, abstention cases, editable/approvable/rejectable candidates, provenance, and JSON export. Only human-approved candidates can be imported; generated cases remain unverified until reviewed.
- Optional LLM judge: advisory semantic correctness/evidence-support judgment from the case inspector; it does not change deterministic metrics.
- Authenticated synchronous evaluation webhook (`POST /api/evaluate-webhook`) accepts a dataset/configuration, calculates deterministic metrics, applies regression gates, and returns a fingerprinted report. It uses bearer `SYNAPSE_WEBHOOK_SECRET` and optional idempotency keys. Reports/jobs are not durably persisted across serverless instances and no notification destination is configured.
- Unit tests cover core formulas, import validation, mocked OpenAI responses/errors, and the authenticated evaluation webhook. Mock tests do not verify live provider connectivity.


## Synthetic testing workflow

1. Open **AI Benchmark Generator / Synthetic testing lab** and supply source passages as JSON (`[{"id":"doc-1","text":"..."}]`).
2. Select a strategy and difficulty, then generate candidates. Supported strategies: adversarial answerable, multi-passage, misleading assumption, insufficient evidence/abstention, conflicting sources, citation-sensitive, and retrieval-hard.
3. Inspect/edit every candidate, verify evidence IDs against source passages, then explicitly **Approve** or **Reject** it. Only approved candidates can be imported. Export candidates as JSON at any review stage.
4. Import approved cases, add real generated answers/retrieved passages from your RAG pipeline, and run the existing deterministic evaluation. Synthetic cases are not a validated benchmark until reviewed and appropriately populated.
5. The optional LLM judge is advisory and separate from deterministic scores. Conflicting-source labels require a human to verify that source passages truly conflict.

## Authenticated automated evaluation webhook

`POST /api/evaluate-webhook` is a synchronous reporting path. Configure `SYNAPSE_WEBHOOK_SECRET` server-side, then send `Authorization: Bearer <secret>` and JSON with `dataset`, `config`, optional `gates`, and optional `event_id` (or `Idempotency-Key`). Dataset is limited to 100 cases and payload to 100 KB. Example request body shape:

```json
{
  "event_id": "ci-build-123",
  "dataset": { "id": "bench-v1", "name": "My benchmark", "cases": [] },
  "config": { "name": "CI evaluation", "k": 5, "requireCitations": true, "metrics": ["retrieval", "correctness", "citations", "unsupported"] },
  "gates": { "retrieval": 0.8, "correctness": 0.7, "citations": 0.9, "unsupported": 0.2 }
}
```

This is a schema illustration; `cases` must contain 1–100 valid test cases. Minimum gates apply to retrieval/correctness/citations; `unsupported` is treated as a maximum failure-rate threshold. A missing metric blocks the gate. The response contains status, run fingerprint, metrics, gates, and findings. Idempotency is best-effort and in-memory per function instance, not durable across serverless instances. No Slack/GitHub notification is configured or claimed.

## Tech stack and rationale

- React + TypeScript + Vite. This is a lightweight alternative to the preferred Next.js stack, selected to keep a hackathon demo fast to install and fully client-side; no server is required for the implemented deterministic engine.
- Plain CSS design system instead of Tailwind to avoid an extra build dependency and keep responsive styling explicit.
- Vitest + jsdom for deterministic evaluator tests. Charts are lightweight CSS-based metric bars; no chart dependency is needed for the current small set of summary metrics.
- Browser `localStorage` for demo persistence. This is per-browser and can be cleared; it is not production multi-user storage.

## Repository structure

```text
Synapse_RAG_Evaluation_Workbench/
├── .github/workflows/ci.yml
├── .env.example
├── .gitignore
├── CONTRIBUTING.md
├── DEPLOYMENT.md
├── LICENSE
├── README.md
├── TEST_REPORT.md
├── FEATURE_AUDIT.md
├── IMPLEMENTATION_PLAN.md
├── FINAL_HANDOFF.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEMO_GUIDE.md
│   └── EVALUATION_METHODOLOGY.md
├── index.html
├── api/
│   ├── generate-benchmark.ts
│   └── judge-answer.ts
├── server/
│   ├── openai.ts
│   └── openai.test.ts
├── package.json
├── tsconfig.json
├── vite.config.ts
└── src/
    ├── App.tsx
    ├── main.tsx
    ├── styles.css
    ├── types.ts
    ├── data/sample.ts
    └── lib/
        ├── assistant.ts
        ├── assistant.test.ts
        ├── evaluator.ts
        ├── evaluator.test.ts
        └── io.ts
```

## Prerequisites

- Node.js 20+ (tested in this build environment with Node 22)
- npm 10+
- A modern browser

## Installation and local development

```bash
npm install
npm run typecheck
npm run lint
npm test -- --run
npm run build
npm run dev
```

For the frontend alone, `npm run dev` is available. To exercise OpenAI server functions locally, run `cp .env.example .env` (PowerShell: `Copy-Item .env.example .env`), privately edit `.env` to set `OPENAI_API_KEY` and optionally `OPENAI_MODEL`, then run `npx vercel dev` instead of `npm run dev`. Do not paste the key into source code or chat. In Vercel, set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` under **Project → Settings → Environment Variables**, choose Development/Preview/Production as needed, save, and redeploy. For the optional evaluation webhook, set a high-entropy `SYNAPSE_WEBHOOK_SECRET` (at least 24 characters) in the same server-side settings. Never prefix secrets with `VITE_`. See [`DEPLOYMENT.md`](DEPLOYMENT.md) for endpoint limits and security details.

Open the local URL printed by the selected development server. No environment variables are required for deterministic evaluation. `.env.example` documents the optional server-side OpenAI integration. AI features use Vercel Functions; use `npx vercel dev` locally so `/api/*` endpoints are served. The supplied project currently has no lockfile. A lockfile could not be generated in the authoring environment because npm registry DNS was unavailable. Run `npm install` once connectivity is restored and commit the generated `package-lock.json`; use `npm ci` for later clean installs.

## Verification status

The supplied development environment could not fetch npm packages because DNS resolution for `registry.npmjs.org` returned `EAI_AGAIN`. Core TypeScript checks and direct runtime smoke assertions passed, but the full Vitest suite, production build, and browser workflow have not passed verification. See [`TEST_REPORT.md`](TEST_REPORT.md) and [`FEATURE_AUDIT.md`](FEATURE_AUDIT.md) for exact results and remaining work.

## Production build

```bash
npm run lint
npm test
npm run build
npm run preview
```

## How to use

1. On Overview, choose **Explore Sample Evaluation** to execute the bundled fictional shipment-policy dataset, or choose **Launch Workbench** to manage your local datasets.
2. Set a run name and retrieval cutoff `k`; choose metrics and whether citations are required.
3. Run the evaluator. Results are saved locally and the result view opens.
4. Select any case to inspect question, generated answer, reference, retrieved passages, citation IDs, each metric explanation, and heuristic debugging suggestions.
5. Repeat after changing a case or importing a revised dataset. Use **Compare Runs** to compare saved results. Comparisons warn if dataset IDs or case IDs differ and show cutoff changes.
6. Use **Reports** or the export buttons to download JSON, CSV, or Markdown.

### Importing data

Supported extensions: `.json`, `.jsonl`, `.csv`. The file is parsed locally and limited to 2 MB. JSON accepts either an array or `{ "cases": [...] }`. JSONL uses one JSON object per line. CSV column mapping:

- Required: `id`, `question`
- Optional: `retrieved_contexts`, `generated_answer`, `reference_answer`, `expected_evidence`, `citations`
- `retrieved_contexts` can be a JSON array of `{ "id", "text", "relevant"? }` or plain text, which is converted into one context.
- `expected_evidence` and `citations` are JSON arrays encoded inside the CSV cell.

Each case requires a string ID and question. Each context requires string ID and text. Malformed fields return a validation error. PDF and other document ingestion are not implemented.

### Sample data

The sample describes a fictional delayed-shipment reimbursement policy with an illustrative cap of ₹25,000 per eligible shipment, subject to eligibility conditions. Sample dataset and seeded scenario data must not be interpreted as actual customer data or validated benchmark outcomes. Use the built-in sample dataset or import the JSON sample downloaded from the Import dialog.

## Metric definitions and limitations

See [`docs/EVALUATION_METHODOLOGY.md`](docs/EVALUATION_METHODOLOGY.md). The deterministic evaluator does not calculate Recall@k, semantic entailment, or semantic contradiction. The optional LLM judge provides an advisory case-level judgment, not a calibrated metric or proof of truth. Claim-to-passage overlap findings are heuristic only; valid citation IDs are not treated as proof of support. Missing reference answers and missing relevance labels are shown as unavailable instead of assigning fabricated scores.

## Persistence, security, and privacy

- Runs and datasets are saved in browser `localStorage`; clearing site data removes them.
- Imported files are parsed as text/data, never executed, and limited to 2 MB.
- Avoid importing confidential production data into a shared or untrusted browser profile.
- The deterministic evaluator does not send content to an external API. The optional AI Benchmark Generator and LLM judge send user-selected passages/case content to OpenAI only after the user activates those actions, through server-side Vercel Functions.
- `OPENAI_API_KEY` is read only by server-side functions. Never use a `VITE_` key variable; do not store keys in localStorage or source code.
- The app is not a guarantee of production safety, factual reliability, or policy compliance.

## Deployment

See [`DEPLOYMENT.md`](DEPLOYMENT.md). The deterministic client can run without credentials. The optional OpenAI endpoints require Vercel Functions (or a compatible server runtime) and server-side `OPENAI_API_KEY`; a static-only host will not provide the `/api/*` endpoints. Do not claim a production URL until you deploy and verify it yourself.

## Testing

See [`TEST_REPORT.md`](TEST_REPORT.md) for commands actually run and results. Automated tests use deterministic fixtures and mocked OpenAI responses; they do not call OpenAI or verify live API connectivity.

## Screenshots

Screenshots have not been captured in this environment. Run the app locally and add genuine screenshots here if desired; no mock screenshot is represented as a real application capture.

## Team

- Team: Synapse
- Team Leader: Anirudh Gangeyula — 25BEV7046
- Participant: Nikhila — 25BEV7111
- Participant: Mahesh — 25BCA7151
- Participant: Shloka — 25MIS7059

## License

MIT. See [`LICENSE`](LICENSE).

## Troubleshooting

- **`npm install` fails:** use a supported Node/npm version and retry with network access.
- **No scores for a metric:** check whether required reference answers, relevance labels, expected evidence, or citations are present. Unavailable is intentional when ground truth is missing.
- **Run history disappeared:** browser storage may have been cleared or a different browser/profile is being used.
- **Imported CSV fails:** quote cells containing commas and encode array-valued cells as valid JSON strings.
- **Port in use:** Vite prints an alternate port, or run `npm run dev -- --port 5174`.

## Local assistant and themes

The **Assistant** page provides deterministic local help for supported metric questions, selected dataset counts, saved run summaries, and case IDs. Answers are generated by transparent rules in `src/lib/assistant.ts`; this is **not** a generative LLM and it declines questions it cannot answer from known rules or current application state. Case answers link to the actual case and evidence IDs when those IDs are available.

The header theme selector supports Light, Dark, and System preferences. The selection is stored in browser `localStorage` under `synapse.theme`. Theme rendering has been implemented in CSS but still needs manual browser verification across all page types.

## Feature audit and verification status

See [`FEATURE_AUDIT.md`](./FEATURE_AUDIT.md) for a source-file-based status audit. Do not treat a visible page or control as proof of end-to-end completion. In the current development environment, `npm install` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. The dependency-backed test, lint, and production-build commands did not pass. A strict type check of the non-React core modules, syntax transpilation of all 10 TypeScript/TSX files, and 17 direct runtime smoke assertions passed; these do not substitute for the full Vitest suite, production build, or browser testing.

## Final hackathon sprint additions

- The Overview welcome copy now uses the requested “Your RAG pipeline has failures. Find out why.” message and exposes real workbench/sample-evaluation actions.
- Evaluation presets (Quick Check, Retrieval Audit, Citation Audit, Regression Test) update the actual deterministic evaluator configuration.
- Workflow Explorer documents the current local data flow and explicitly calls out integrations that are not implemented.
- New runs include a deterministic dataset-content fingerprint; comparisons use it to warn about changed dataset content. Older saved runs fall back to dataset ID and case IDs.
- Markdown reports include the fingerprint when available.

**Verification note:** pure core TypeScript checks and direct runtime smoke checks passed. The full Vitest suite, full lint, and production build could not run because npm dependencies are not installed in the environment (`vitest` and React declarations are missing). No browser test or deployment is claimed. See `TEST_REPORT.md` and `FEATURE_AUDIT.md`.
