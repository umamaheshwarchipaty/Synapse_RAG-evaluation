# Security changes (audit follow-up)

| Area | Change |
|---|---|
| Auth | AI endpoints require `x-synapse-access-token` = `SYNAPSE_ACCESS_TOKEN`; fail closed if unset. UI field added (sessionStorage). |
| Spend | `max_output_tokens` on every OpenAI call (4,000 benchmark / 1,200 judge). |
| Rate limiting | Shared limiter in `server/security.ts`; webhook now limited; failed-auth attempts throttled (5/min). In-memory only. |
| Headers | `vercel.json`: CSP, X-Frame-Options, nosniff, Referrer-Policy, HSTS, Permissions-Policy, COOP. |
| Webhook | Deeper context validation; generic error message; shared constant-time compare. |
| Dev scripts | Removed `--host 0.0.0.0` from `dev` and `preview`. |
| CI | `permissions: contents: read`; `npm ci` when a lockfile exists; non-blocking `npm audit`. |
| Package | `engines.node >= 20`; `audit` script. |
| Tests | New tests for token auth, fail-closed, throttling, output cap, webhook error hygiene. |

Not verifiable here (no npm registry access): lockfile generation, full typecheck, full test run, `npm audit`. See DEPLOYMENT.md "Manual steps you must still do".
