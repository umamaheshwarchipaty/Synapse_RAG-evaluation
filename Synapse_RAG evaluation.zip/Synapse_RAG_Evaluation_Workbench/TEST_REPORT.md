# Synapse 2.0 — OpenAI Integration Test Report

Date: 2026-10-26. This report distinguishes direct source/runtime checks from dependency-backed tests. No live OpenAI API request, browser E2E session, or Vercel deployment was performed.

## Dependency installation

Command:

```bash
npm install --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=20000
```

**Exit status: 1.** npm failed with `EAI_AGAIN` resolving `registry.npmjs.org/@types%2freact`. The supplied project had no lockfile or `node_modules`; no lockfile was fabricated. React/Vite/Vitest packages therefore remain unavailable in this environment.

## Required project commands

| Command | Actual exit status | Result |
|---|---:|---|
| `npm run typecheck` | 2 | Blocked by unavailable `vitest`, `react`, and `react/jsx-runtime` declarations after failed install. |
| `npm run lint` | 2 | Same dependency/type declaration blocker. This script currently runs TypeScript checks rather than a separate style linter. |
| `npm test -- --run` | 127 | `vitest: not found`. |
| `npm run build` | 1 | `tsc -b` stopped on missing React/Vitest declarations; Vite production bundling was not reached. |

These are environment-blocked outcomes, not passing builds or tests.

## Checks that passed in this integration pass

1. **Server endpoint type-check — PASS, exit 0**

   ```bash
   tsc --strict --target ES2022 --module ESNext --moduleResolution Bundler --lib ES2022,DOM --skipLibCheck --noEmit server/openai.ts api/generate-benchmark.ts api/judge-answer.ts
   ```

2. **TypeScript/TSX syntax transpilation — PASS.** The TypeScript compiler API transpiled 8 related source/test files with zero syntax diagnostics: `src/App.tsx`, both new React components, `src/main.tsx`, the server integration and its tests, and both API endpoints. This is syntax-only verification, not a full React-aware type-check.

3. **Direct API runtime smoke checks — PASS, 10 assertions.** The server helper was compiled with the globally available TypeScript compiler and exercised with mocked fetch responses. Assertions covered successful structured benchmark response, missing key, invalid/hallucinated evidence ID rejection, sanitized provider 429 handling, duplicate IDs, method validation, invalid candidate count, successful mocked judge response, invalid judge evidence IDs, and judge request validation.

4. The baseline `TEST_REPORT.md` from the supplied project records 29 earlier direct Node smoke assertions for deterministic evaluator/import behavior. Those baseline assertions were not rerun during this OpenAI integration pass.

## Automated tests added, but not executed

`server/openai.test.ts` adds 9 Vitest tests using mocked OpenAI responses for request validation, missing configuration, structured candidate validation, provider rate limits, methods, and LLM judge output validation. Together with the existing test files there are 47 `it(...)` cases in source. **The Vitest suite did not run** because Vitest could not be installed. Mocked tests are not live API connectivity tests.

## Security/configuration checks by source inspection

- `OPENAI_API_KEY` and `OPENAI_MODEL` are read only by the server-side API entry points.
- No `VITE_OPENAI_API_KEY`, frontend environment access, browser storage of secrets, or response field containing the key was added.
- `.env` is ignored by `.gitignore`; `.env.example` contains placeholder values only.
- Endpoint responses do not log or return provider response bodies or secrets. Rate limiting is best-effort in-memory per serverless instance.

## Remaining verification steps

After npm registry connectivity is restored:

```bash
npm install
npm run typecheck
npm run lint
npm test -- --run
npm run build
```

Then copy `.env.example` to `.env`, set the key privately, and run `npx vercel dev` to exercise `/api/*` locally. Configure the same environment variables in Vercel Project Settings, deploy, and test the AI generator and judge in the browser. No live API request or deployment has been claimed here.


## Synapse 2.1 additions (current source)

- Added `server/evaluation-webhook.test.ts` with mocked/local tests for authentication, payload validation, metric report, unavailable-gate blocking, idempotent replay, and threshold validation.
- Updated `server/openai.test.ts` for the expanded synthetic candidate schema and added strategy-validation and abstention cases. These tests mock OpenAI responses and do not prove live API connectivity.
- Full Vitest/lint/type-check/build outcomes must be refreshed by running the commands listed below in an environment where npm dependencies can be installed. The supplied archive has no `node_modules` or lockfile; no live OpenAI call or browser test is claimed.

Commands: `npm install`, `npm run typecheck`, `npm run lint`, `npm test -- --run`, `npm run build`.


## Exact verification run for Synapse 2.1 quality pass

Environment: Node v22.16.0; uploaded source archive had no `node_modules` or package lockfile. A local `.env` was present in the supplied archive and was excluded from the deliverable without reading its contents.

| Command/check | Actual result |
|---|---|
| `npm install --no-audit --no-fund --fetch-retries=0 --fetch-timeout=20000` | **BLOCKED**, exit 1: `EAI_AGAIN` resolving `registry.npmjs.org/@types%2freact`. |
| `npm run typecheck` | **BLOCKED**, exit 1: missing installed `react`, `react-dom`, `react/jsx-runtime`, and `vitest` declarations; many downstream JSX typing errors are consequences of missing dependencies. |
| `npm run lint` | **BLOCKED**, exit 2: this project script is `tsc --noEmit`, and it encounters the same missing dependency/type declarations. There is no separate ESLint script. |
| `npm test -- --run` | **BLOCKED**, exit 127: `vitest: not found`. |
| `npm run build` | **BLOCKED**, exit 1 during TypeScript build due to missing dependencies/types; Vite production bundle was not produced. |
| Strict core check: `tsc --strict --target ES2022 --module ESNext --moduleResolution Bundler --lib ES2022,DOM --skipLibCheck --noEmit src/types.ts src/lib/evaluator.ts server/openai.ts server/evaluation-webhook.ts` | **PASS**, exit 0. |
| TypeScript syntax transpilation | **PASS**, 14 `.ts`/`.tsx` source files transpiled without syntax diagnostics (not a full type-check). |
| Direct Node runtime smoke assertions | **PASS**, 11 assertions for missing-key handling, mocked structured generation, invalid evidence rejection, abstention validation, webhook authentication, regression gates, idempotency, threshold validation, and expected-abstention evaluation. These are not the Vitest suite and do not verify live OpenAI connectivity. |

No browser end-to-end test, live OpenAI request, or Vercel deployment was performed. After network access is restored, run `npm install`, then `npm run typecheck`, `npm run lint`, `npm test -- --run`, and `npm run build`. Commit the generated `package-lock.json` for reproducible installs.
- Additional source check: strict TypeScript check of evaluator/server code and evaluator/server test files using a temporary ambient `vitest` declaration stub passed with exit 0. This checks project types without the actual Vitest package; it is not a substitute for the real test runner and does not type-check the React UI.
