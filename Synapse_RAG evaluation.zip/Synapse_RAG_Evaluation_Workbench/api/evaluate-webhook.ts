import { createEvaluationWebhook } from '../server/evaluation-webhook';
const env = (globalThis as typeof globalThis & { process?: { env?: Record<string, string | undefined> } }).process?.env ?? {};
export default createEvaluationWebhook({ SYNAPSE_WEBHOOK_SECRET: env.SYNAPSE_WEBHOOK_SECRET });
