import { createBenchmarkHandler } from '../server/openai';
const env = (globalThis as typeof globalThis & { process?: { env?: Record<string, string | undefined> } }).process?.env ?? {};
export default createBenchmarkHandler({ OPENAI_API_KEY: env.OPENAI_API_KEY, OPENAI_MODEL: env.OPENAI_MODEL, SYNAPSE_ACCESS_TOKEN: env.SYNAPSE_ACCESS_TOKEN });
