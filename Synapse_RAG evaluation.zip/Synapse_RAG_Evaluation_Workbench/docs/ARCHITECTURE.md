# Architecture

The UI is a React + TypeScript + Vite single-page app. The deterministic evaluation engine remains client-side and independent of OpenAI configuration.

- `src/types.ts`: shared data contracts for cases, datasets, configuration, metric results, and runs.
- `src/data/sample.ts`: fictional shipment policy fixtures, clearly marked sample.
- `src/lib/evaluator.ts`: pure deterministic metric logic, orchestration, aggregate helpers, and bounded counterfactual evaluation.
- `src/lib/io.ts`: JSON/JSONL/CSV parsing, validation, report generation, and downloads.
- `src/components/AIBenchmarkGenerator.tsx`: opt-in benchmark generation UI and review-before-import flow.
- `src/components/LLMJudgePanel.tsx`: opt-in advisory answer/evidence judgment in the case inspector.
- `api/generate-benchmark.ts`: Vercel Function for benchmark generation.
- `api/judge-answer.ts`: Vercel Function for optional LLM judging.
- `server/openai.ts`: shared server-only OpenAI Responses API calls, request limits, structured-output validation, sanitized errors, and best-effort rate limiting.
- `server/openai.test.ts`: unit tests with mocked fetch responses; these do not make live OpenAI requests.
- `src/App.tsx`: navigation, dashboard, dataset management, configuration, results, case inspector, comparisons, reports, settings, and team page.
- `src/styles.css`: responsive light/dark/system design system and interactive-state styles.
- `localStorage`: persistence for datasets and runs in the current browser profile. API keys are not stored in localStorage.

The optional AI endpoints require `OPENAI_API_KEY` in the server-side environment and use `OPENAI_MODEL` when set (default `gpt-4.1-mini`). They are served locally by `npx vercel dev` and deployed as Vercel Functions. The API key is not exposed to frontend code. The benchmark generator returns candidate questions, reference answers, and source evidence IDs for human review before import. The LLM judge returns advisory categorical judgments; it does not change deterministic run metrics and is not calibrated. No external retriever/generator, trace ingestion, database, or authentication is implemented.
