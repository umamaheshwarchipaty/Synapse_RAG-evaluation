# Five-minute hackathon demo — Synapse 2.0

All shipment-policy content is fictional and illustrative. Do not present these values as customer data or independent benchmark results.

## Reproducible script

1. **0:00–0:30 — Product purpose.** Open Overview. Explain that Synapse measures a deterministic local baseline and helps trace failures to retrieved evidence. Point out that no login or API key is needed.
2. **0:30–1:15 — Run sample.** Click **Explore Sample Evaluation**. This action runs the bundled sample dataset through `makeRun`/the deterministic evaluator using k=3 and the four configured metrics. The UI should open the newly saved run. In direct execution of the bundled sample, the current source produces 4 cases, 2 cases with failure flags, and 7 structured findings; these values are illustrative and may change when the sample or evaluator changes.
3. **1:15–2:15 — Inspect a failure.** Open `SHIP-001`. Show its question, generated answer, reference answer, retrieved contexts, citation records, metric explanations, and findings. Explain that retrieval misses and invalid citation IDs are deterministic checks, while lexical overlap findings are heuristic signals, not proof of semantic correctness.
4. **2:15–3:00 — Evidence navigation.** Select an evidence ID from a finding. Confirm the matching retrieved passage scrolls into view if it exists. Explain that a missing passage is surfaced rather than invented.
5. **3:00–3:45 — Dataset quality and analytics.** Open Datasets → Import dataset and select a JSON/JSONL/CSV file to preview its cases, reference coverage, relevance-label coverage, duplicate IDs, and citation/evidence warnings before confirming import. Open Analytics to filter the selected saved run by finding category or severity and navigate to a case.
6. **3:45–4:25 — Counterfactual Lab and comparisons.** In Counterfactual Lab, select a case and change k. Explain that it re-scores the existing ordered context list and does not rerun retrieval or generation. Then open Compare Runs for saved-run differences. Do not infer causality from a score change alone.
7. **4:25–5:00 — Reports and honesty.** Export JSON or Markdown from Reports. Show run metadata, methodology, findings, evidence IDs, and limitations. State clearly that the app does not yet have an LLM judge, production backend, external trace integration, or measured cost/latency instrumentation.

## Browser verification checklist

This checklist has **not** been executed in a browser in the authoring environment because dependencies could not be installed and no production/dev bundle could be launched. Run it after `npm install`, `npm run lint`, `npm test`, and `npm run build` pass.

- [ ] Overview opens; no-run metrics show N/A instead of fabricated scores.
- [ ] Launch Workbench navigates to the existing Datasets workspace.
- [ ] Explore Sample Evaluation executes the bundled sample on every click and opens the new saved run.
- [ ] A failed case opens with all supplied answers, contexts, citations, findings, and formulas.
- [ ] Evidence ID navigation scrolls to the exact context when present.
- [ ] Feedback persists after refresh.
- [ ] Dataset import preview displays rows, coverage, duplicate IDs, missing evidence, and invalid citation warnings.
- [ ] Structural validation errors disable import; valid datasets import only after confirmation.
- [ ] Analytics updates when a different saved run or filter is selected; category rows filter findings and case links open the correct case.
- [ ] Counterfactual Lab changes k, updates computed scores/findings, and leaves saved runs unchanged.
- [ ] Comparison shows aggregate and per-case differences and warns when configurations differ.
- [ ] Theme preference persists after refresh and remains readable on Overview, modals, Analytics, and Case Inspector.
- [ ] JSON, CSV, and Markdown downloads match the selected saved run.
- [ ] Invalid file formats, malformed data, empty data, and oversized files show actionable errors without crashing.
- [ ] Test desktop and mobile widths and keyboard navigation.

## Five-minute hackathon demo (final sprint)

1. **0:00–0:35 — Problem and promise.** Start on Overview and introduce: “Your RAG pipeline has failures. Find out why.” Emphasize that this is a local-first, inspectable evaluator rather than a black-box judge.
2. **0:35–1:15 — Sample evaluation.** Click **Explore Sample Evaluation**. Explain that the bundled shipment-policy examples are fictional and the evaluator runs deterministically on the actual sample cases.
3. **1:15–2:10 — Failure Explorer.** Open a case with findings. Walk through metric explanations, rule basis, severity, heuristic versus deterministic labels, and evidence IDs. Click a resolvable evidence ID and point out that ID resolution is not proof of semantic support.
4. **2:10–3:00 — Import and presets.** Show JSON/JSONL/CSV import preview and validation. In Run Evaluation, select Retrieval Audit or Citation Audit and point out that the preset changes real evaluator settings.
5. **3:00–4:00 — Analytics and comparison.** Open Analytics. Run a second configuration and compare saved runs. Mention dataset fingerprints and warn that score differences are not causal proof or a semantic-quality guarantee.
6. **4:00–4:35 — Assistant and workflow.** Ask a question supported by the current dataset/run, then open Workflow Explorer. State clearly that the assistant is local rules-based, not an LLM.
7. **4:35–5:00 — Reports and honest limitations.** Export Markdown/JSON/CSV. Close with next steps: restore dependencies, run full build/tests, and connect a real pipeline only through a tested adapter/server-side integration.


## Synthetic testing and reporting add-on

1. Open AI Benchmark Generator, select a strategy (try insufficient evidence), choose difficulty and candidate count, and generate with the configured server-side OpenAI API.
2. Demonstrate an abstention candidate with no reference answer/evidence IDs. Edit a candidate, inspect provenance and passage IDs, then approve one and reject another.
3. Export the candidate JSON, then import only approved cases. Explain these are review-required synthetic tests, not a validated benchmark.
4. For automation, call `POST /api/evaluate-webhook` with a valid bearer secret, 1–100 case dataset, config, and gates. Show the returned metrics and gate statuses. Repeating the same `event_id` on the same function instance should replay the same result.
5. Explain that webhook idempotency and reports are in-memory/best-effort, and no external notification integration is configured.
