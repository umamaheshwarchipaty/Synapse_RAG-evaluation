# Evaluation methodology

Synapse implements deterministic baseline signals and intentionally separates them from semantic judgments. Results are diagnostic hints, not guarantees of factual reliability.

## Retrieval relevance

1. If every passage in the selected top-k slice has a boolean `relevant` label, Precision@k is the number of relevant passages divided by the number of passages actually present in that slice. When the slice is empty, a supplied non-empty expected-evidence list scores zero coverage; otherwise the metric is unavailable.
2. Otherwise, when `expected_evidence` exists, evidence coverage is expected evidence IDs found by exact context-ID match in top-k divided by expected evidence items.
3. Otherwise the metric is unavailable. Recall@k is not implemented; a valid complete relevant set is not inferred.

Limitation: exact ID matching and manually supplied labels are not semantic relevance judgments. Partially labeled top-k results are marked unavailable rather than treating unlabeled passages as irrelevant.

## Answer correctness

Normalize case and Unicode, remove punctuation, split into tokens, and calculate F1 over unique tokens between generated and reference answers. If the reference is absent, report unavailable. The score measures lexical overlap only: it is not a factual correctness verdict.

## Citation accuracy

If citation requirement is enabled, no citations means a failure. Otherwise calculate the valid citation ID ratio: citation records whose `context_id` matches a retrieved context ID divided by citation records. If all IDs resolve, verdict is `review`, not an unconditional pass, because ID existence cannot prove claim support. Invalid IDs fail. Claim text is shown next to the cited passage for manual inspection.

## Unsupported answers

Heuristic flag is raised when the answer is empty, no context exists for a non-empty answer, or no retrieved context has token-overlap F1 of at least 0.16 with the generated answer. This simple baseline can miss unsupported claims in a partly grounded answer and can flag paraphrases. It is not an entailment model and does not automatically detect contradictions.

## Failure diagnosis

Structured findings identify a category, severity, trigger basis, linked context IDs, method (`deterministic` or `heuristic`), and next investigation. Some finding categories use deterministic input/ID rules; lexical overlap findings are heuristic. Local feedback can mark findings correct, incorrect, or uncertain. These signals do not prove causal root causes.

## Reproducibility

Given the same case data and configuration, these metric functions are deterministic. Each run stores timestamp, dataset identifier/name, configuration, case IDs, per-case results, and structured findings. Selected metric configuration is honored: disabled metrics are unavailable and do not contribute failure flags. Browser localStorage is not a shared or durable production database. Random run IDs and timestamps vary between runs, not the metric calculations.


## Optional LLM judgment (separate from deterministic metrics)

When configured, the case inspector can send a selected question, answer, reference answer, and retrieved passages to the server-side `/api/judge-answer` endpoint. The configured OpenAI model returns categorical answer-correctness and evidence-support judgments plus evidence IDs. The server validates the output against the supplied context IDs. This is an advisory model judgment that may be wrong; it is not calibrated, is not aggregated into deterministic run metrics, and does not establish ground truth. Automated tests mock provider responses and do not verify live provider connectivity.
