import type { Dataset, EvalConfig, TestCase } from '../src/types';
import { aggregate, makeRun } from '../src/lib/evaluator';
import { headerValue, hitLimit, safeEqual } from './security';

export type WebhookRequest = { method?: string; body?: unknown; headers?: Record<string, string | string[] | undefined> };
export type WebhookResponse = { status(code: number): WebhookResponse; json(value: unknown): void; setHeader(name: string, value: string): void };
type Env = { SYNAPSE_WEBHOOK_SECRET?: string };
const MAX_BODY = 100_000;
const completed = new Map<string, { at: number; payload: unknown }>();
function reply(res: WebhookResponse, status: number, body: unknown) { res.setHeader('Cache-Control','no-store'); res.setHeader('X-Content-Type-Options','nosniff'); res.status(status).json(body); }
const header = (req: WebhookRequest, name: string): string => headerValue(req.headers, name);
export function createEvaluationWebhook(env: Env) {
  return async (req: WebhookRequest, res: WebhookResponse) => {
    if (req.method !== 'POST') { res.setHeader('Allow','POST'); return reply(res,405,{error:'Method not allowed.'}); }
    if (hitLimit('webhook', req.headers, 30)) return reply(res,429,{error:'Too many requests. Wait a minute and try again.'});
    const secret = env.SYNAPSE_WEBHOOK_SECRET;
    if (!secret || secret.length < 24) return reply(res,503,{error:'Evaluation webhook is not configured. Set SYNAPSE_WEBHOOK_SECRET (at least 24 characters).'});
    const authorization = header(req,'authorization');
    if (!authorization.startsWith('Bearer ') || !safeEqual(authorization.slice(7),secret)) {
      if (hitLimit('webhook-denied', req.headers, 5)) return reply(res,429,{error:'Too many failed attempts. Wait a minute and try again.'});
      return reply(res,401,{error:'Unauthorized.'});
    }
    let serialized = ''; try { serialized = JSON.stringify(req.body ?? null); } catch { return reply(res,400,{error:'Request body must be valid JSON.'}); }
    if (serialized.length > MAX_BODY) return reply(res,413,{error:'Request body exceeds 100 KB.'});
    const body = req.body as Record<string,unknown> | null;
    if (!body || typeof body !== 'object' || Array.isArray(body)) return reply(res,400,{error:'Request body must be an object.'});
    const idempotencyKey = header(req,'idempotency-key') || (typeof body.event_id === 'string' ? body.event_id : '');
    if (idempotencyKey && (idempotencyKey.length > 160 || !/^[a-zA-Z0-9._:-]+$/.test(idempotencyKey))) return reply(res,400,{error:'Idempotency key must be 1–160 safe characters.'});
    const now = Date.now(); for (const [key,item] of completed) if (now-item.at > 10*60_000) completed.delete(key);
    if (idempotencyKey && completed.has(idempotencyKey)) return reply(res,200,{...completed.get(idempotencyKey)!.payload as object, idempotent_replay:true});
    const dataset = body.dataset as Dataset | undefined; const config = body.config as EvalConfig | undefined;
    if (!dataset || typeof dataset.id !== 'string' || typeof dataset.name !== 'string' || !Array.isArray(dataset.cases) || dataset.cases.length < 1 || dataset.cases.length > 100) return reply(res,400,{error:'dataset must contain an id, name, and 1–100 test cases.'});
    if (!config || typeof config.name !== 'string' || !Number.isInteger(config.k) || config.k < 1 || config.k > 20 || typeof config.requireCitations !== 'boolean' || !Array.isArray(config.metrics) || !config.metrics.length || config.metrics.some(m=>!['retrieval','correctness','citations','unsupported'].includes(m))) return reply(res,400,{error:'Invalid evaluation configuration.'});
    if (dataset.cases.some((c: TestCase)=>!c || typeof c.id!=='string' || typeof c.question!=='string' || !Array.isArray(c.retrieved_contexts) || c.retrieved_contexts.some(x=>!x || typeof x.id!=='string' || typeof x.text!=='string'))) return reply(res,400,{error:'Each case requires id, question, and retrieved_contexts (each with string id and text).'});
    const gates = (body.gates && typeof body.gates === 'object' ? body.gates : {}) as Record<string,unknown>;
    const gateKeys = ['retrieval','correctness','citations','unsupported'];
    for (const key of gateKeys) if (gates[key] !== undefined && (typeof gates[key] !== 'number' || !Number.isFinite(gates[key]) || (gates[key] as number)<0 || (gates[key] as number)>1)) return reply(res,400,{error:`Gate ${key} must be a number between 0 and 1.`});
    try {
      const run = makeRun(config.name,dataset.id,dataset.name,dataset.cases,{...config,metrics:[...new Set(config.metrics)]},false);
      const metrics = { retrieval:aggregate(run.results,'retrieval'), correctness:aggregate(run.results,'correctness'), citations:aggregate(run.results,'citations'), unsupported:aggregate(run.results,'unsupported') };
      const gateResults = Object.fromEntries(gateKeys.filter(k=>gates[k]!==undefined).map(k=>{ const actual=metrics[k as keyof typeof metrics]; const threshold=gates[k] as number; const passes=actual!==null && (k==='unsupported' ? actual<=threshold : actual>=threshold); return [k,{comparison:k==='unsupported'?'maximum':'minimum',threshold,actual,status:actual===null?'blocked':passes?'passed':'failed'}]; }));
      const blocked = Object.values(gateResults).some((g:any)=>g.status==='blocked');
      const failed = Object.values(gateResults).some((g:any)=>g.status==='failed');
      const report = { status:Object.keys(gateResults).length===0?'blocked':blocked?'blocked':failed?'failed':'passed', evaluationStatus:'completed', ...(Object.keys(gateResults).length===0?{blockedReason:'No regression gates were configured.'}:{}), run:{id:run.id,name:run.name,timestamp:run.timestamp,datasetFingerprint:run.datasetFingerprint,config:run.config,evaluator:'deterministic-heuristic-v1'}, dataset:{id:dataset.id,name:dataset.name,caseCount:dataset.cases.length}, metrics, gateResults, failureCount:run.results.filter(r=>r.failures.length).length, findings:run.results.flatMap(r=>(r.findings??[]).map(f=>({caseId:r.caseId,...f}))).slice(0,200), notes:['Synchronous evaluation; report returned in this response.','This serverless endpoint does not persist jobs or reports across instances.','Lexical overlap is a heuristic, not proof of semantic correctness.','No notification destination is configured by this endpoint.'] };
      if (idempotencyKey) { completed.set(idempotencyKey,{at:now,payload:report}); while(completed.size>500) completed.delete(completed.keys().next().value as string); }
      return reply(res,200,report);
    } catch { return reply(res,400,{error:'Evaluation failed. Check the dataset and config shapes and try again.'}); }
  };
}
