import { describe, it, expect, vi } from 'vitest';
import { createBenchmarkHandler, createJudgeHandler, type ApiRequest, type ApiResponse } from './openai';

const TOKEN = 'test-access-token-1234567890abcd';
function invoke(handler: (req: ApiRequest, res: ApiResponse) => Promise<void>, body: unknown, options: { method?: string; ip?: string; token?: string | null } = {}) {
  const result: { statusCode: number; payload: unknown; headers: Record<string, string> } = { statusCode: 200, payload: null, headers: {} };
  const res: ApiResponse = { status(code) { result.statusCode = code; return this; }, json(value) { result.payload = value; }, setHeader(name, value) { result.headers[name] = value; } };
  const req: ApiRequest = { method: options.method ?? 'POST', body, headers: { 'x-forwarded-for': options.ip ?? `test-${Math.random()}`, ...(options.token === null ? {} : { 'x-synapse-access-token': options.token ?? TOKEN }) } };
  return handler(req, res).then(() => result);
}
const passages = [{ id: 'doc-a', text: 'Refunds are capped at 500 dollars for eligible delayed deliveries.' }];
const outputResponse = (payload: unknown, status = 200) => new Response(JSON.stringify(payload), { status, headers: { 'Content-Type': 'application/json' } });
const openAIResponse = (output: unknown) => outputResponse({ output_text: JSON.stringify(output) });

describe('server-side OpenAI benchmark endpoint', () => {
  it('rejects invalid requests before calling OpenAI', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages: [{ id: 'x', text: 'y' }, { id: 'x', text: 'z' }] });
    expect(result.statusCode).toBe(400);
    expect(result.payload).toMatchObject({ error: expect.stringContaining('Duplicate passage ID') });
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('keeps AI optional when the server key is absent', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createBenchmarkHandler({ SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    expect(result.statusCode).toBe(503);
    expect(result.payload).toMatchObject({ error: expect.stringContaining('not configured') });
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('calls mocked OpenAI and accepts only supplied evidence IDs', async () => {
    const fetcher = vi.fn(async (_url: RequestInfo | URL, _init?: RequestInit) => openAIResponse({ candidates: [{ id: 'c1', question: 'What is the cap?', reference_answer: '500 dollars.', expected_behavior: 'answer', evidence_ids: ['doc-a'], strategy: 'adversarial_answerable', difficulty: 'medium', challenge: 'Requires extracting the numeric cap.' }] }));
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', OPENAI_MODEL: 'mock-model', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    expect(result.statusCode).toBe(200);
    expect(result.payload).toMatchObject({ model: 'mock-model', candidates: [{ evidence_ids: ['doc-a'] }] });
    const init = fetcher.mock.calls[0]?.[1] as RequestInit;
    expect((init.headers as Record<string, string>).Authorization).toBe('Bearer test-secret');
  });
  it('rejects hallucinated evidence IDs from a mocked provider response', async () => {
    const fetcher = vi.fn(async () => openAIResponse({ candidates: [{ id: 'c1', question: 'Q?', reference_answer: 'A.', expected_behavior: 'answer', evidence_ids: ['not-in-source'], strategy: 'adversarial_answerable', difficulty: 'medium', challenge: 'Test invalid evidence.' }] }));
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    expect(result.statusCode).toBe(502);
    expect(result.payload).toMatchObject({ error: expect.stringContaining('schema or evidence-ID validation') });
  });
  it('maps provider rate limits to HTTP 429 without leaking provider response text', async () => {
    const fetcher = vi.fn(async () => new Response('secret provider details', { status: 429 }));
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    expect(result.statusCode).toBe(429);
    expect(JSON.stringify(result.payload)).not.toContain('secret provider details');
  });
  it('rejects unsupported synthetic strategies before calling OpenAI', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1, strategy: 'invent-a-conflict' });
    expect(result.statusCode).toBe(400);
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('accepts an abstention candidate without inventing a reference answer or evidence', async () => {
    const fetcher = vi.fn(async () => openAIResponse({ candidates: [{ id: 'c-abstain', question: 'Which carrier caused this?', reference_answer: '', expected_behavior: 'abstain', evidence_ids: [], strategy: 'insufficient_evidence', difficulty: 'hard', challenge: 'The sources do not name a carrier.' }] }));
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1, strategy: 'insufficient_evidence', difficulty: 'hard' });
    expect(result.statusCode).toBe(200);
    expect(result.payload).toMatchObject({ candidates: [{ expected_behavior: 'abstain', reference_answer: '', evidence_ids: [] }] });
  });
  it('rejects non-POST requests', async () => {
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }), {}, { method: 'GET' });
    expect(result.statusCode).toBe(405);
    expect(result.headers.Allow).toBe('POST');
  });
});

describe('optional LLM judge endpoint', () => {
  it('validates answer input before calling the provider', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createJudgeHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { question: '', answer: 'answer', contexts: [] });
    expect(result.statusCode).toBe(400);
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('returns a validated advisory judgment from a mocked provider response', async () => {
    const fetcher = vi.fn(async () => openAIResponse({ answer_correctness: 'partially_correct', evidence_support: 'supported', rationale: 'The answer matches the supplied policy.', supporting_evidence_ids: ['doc-a'] }));
    const result = await invoke(createJudgeHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { question: 'What is the cap?', answer: '500 dollars.', reference_answer: '500 dollars', contexts: passages });
    expect(result.statusCode).toBe(200);
    expect(result.payload).toMatchObject({ judgment: { evidence_support: 'supported', supporting_evidence_ids: ['doc-a'] } });
  });
  it('rejects judge evidence IDs that do not exist in the request', async () => {
    const fetcher = vi.fn(async () => openAIResponse({ answer_correctness: 'correct', evidence_support: 'supported', rationale: 'Seems right.', supporting_evidence_ids: ['fake-id'] }));
    const result = await invoke(createJudgeHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { question: 'Q?', answer: 'A.', contexts: passages });
    expect(result.statusCode).toBe(502);
    expect(result.payload).toMatchObject({ error: expect.stringContaining('failed validation') });
  });
});

describe('access control and spend safeguards', () => {
  const okOutput = { candidates: [{ id: 'c1', question: 'What is the cap?', reference_answer: '500 dollars.', expected_behavior: 'answer', evidence_ids: ['doc-a'], strategy: 'adversarial_answerable', difficulty: 'medium', challenge: 'Needs the numeric cap.' }] };
  it('rejects requests without an access token and never calls OpenAI', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 }, { token: null });
    expect(result.statusCode).toBe(401);
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('rejects a wrong access token on the judge endpoint', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createJudgeHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { question: 'Q?', answer: 'A.', contexts: passages }, { token: 'wrong-token' });
    expect(result.statusCode).toBe(401);
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('fails closed when no server access token is configured', async () => {
    const fetcher = vi.fn();
    const result = await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret' }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    expect(result.statusCode).toBe(503);
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('throttles repeated failed token guesses from one IP', async () => {
    const handler = createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, vi.fn() as unknown as typeof fetch);
    const codes: number[] = [];
    for (let i = 0; i < 8; i++) codes.push((await invoke(handler, { passages, count: 1 }, { ip: 'attacker-1', token: `guess-${i}` })).statusCode);
    expect(codes.slice(0, 5).every(c => c === 401)).toBe(true);
    expect(codes[7]).toBe(429);
  });
  it('sends max_output_tokens to cap provider spend per request', async () => {
    const fetcher = vi.fn(async (_u: RequestInfo | URL, _i?: RequestInit) => openAIResponse(okOutput));
    await invoke(createBenchmarkHandler({ OPENAI_API_KEY: 'test-secret', SYNAPSE_ACCESS_TOKEN: TOKEN }, fetcher as unknown as typeof fetch), { passages, count: 1 });
    const body = JSON.parse(String((fetcher.mock.calls[0]?.[1] as RequestInit).body));
    expect(body.max_output_tokens).toBeGreaterThan(0);
    expect(body.max_output_tokens).toBeLessThanOrEqual(4000);
  });
});
