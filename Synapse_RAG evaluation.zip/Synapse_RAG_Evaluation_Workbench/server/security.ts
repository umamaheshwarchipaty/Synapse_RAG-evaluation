// Shared security helpers for the serverless API handlers.
// NOTE: state here is in-memory and per serverless instance. It is a best-effort
// speed bump; use Vercel Firewall rate limiting (or a shared store) for durable limits.

type HeaderMap = Record<string, string | string[] | undefined> | undefined;
type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
const MAX_BUCKETS = 5_000;

export function headerValue(headers: HeaderMap, name: string): string {
  const value = headers?.[name] ?? headers?.[name.toLowerCase()];
  return Array.isArray(value) ? value[0] ?? '' : value ?? '';
}

export function clientIp(headers: HeaderMap): string {
  return headerValue(headers, 'x-forwarded-for').split(',')[0]?.trim() || 'unknown';
}

/** Constant-time string comparison (does not short-circuit on the first differing character). */
export function safeEqual(a: string, b: string): boolean {
  let diff = a.length ^ b.length;
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}

/** Returns true when the caller has exceeded `limit` hits for `scope` within the window. */
export function hitLimit(scope: string, headers: HeaderMap, limit: number, windowMs = 60_000): boolean {
  const key = `${scope}:${clientIp(headers)}`;
  const now = Date.now();
  for (const [k, b] of buckets) if (b.resetAt <= now) buckets.delete(k);
  if (buckets.size > MAX_BUCKETS) buckets.clear(); // memory guard against key-flooding
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) { buckets.set(key, { count: 1, resetAt: now + windowMs }); return false; }
  bucket.count++;
  return bucket.count > limit;
}

export type AccessResult = 'ok' | 'not_configured' | 'denied';

/** Validates the `x-synapse-access-token` header against SYNAPSE_ACCESS_TOKEN. Fails closed if unset/weak. */
export function checkAccessToken(headers: HeaderMap, configured: string | undefined): AccessResult {
  if (!configured || configured.length < 24) return 'not_configured';
  const provided = headerValue(headers, 'x-synapse-access-token');
  return provided && safeEqual(provided, configured) ? 'ok' : 'denied';
}
