import { useEffect, useMemo, useState } from 'react';
import type { Dataset, TestCase } from '../types';
import { aiHeaders } from '../lib/access';
import AccessTokenField from './AccessTokenField';

type Passage = { id: string; text: string };
type Strategy = 'adversarial_answerable' | 'multi_passage' | 'misleading_assumption' | 'insufficient_evidence' | 'conflicting_sources' | 'citation_sensitive' | 'retrieval_hard';
type Candidate = { id: string; question: string; reference_answer: string; expected_behavior: 'answer' | 'abstain'; evidence_ids: string[]; strategy: Strategy; difficulty: 'easy' | 'medium' | 'hard'; challenge: string; provenance: string; reviewStatus: 'unverified' | 'approved' | 'rejected' };
const strategies: { value: Strategy; label: string }[] = [
  { value: 'adversarial_answerable', label: 'Adversarial but answerable' }, { value: 'multi_passage', label: 'Requires multiple passages' },
  { value: 'misleading_assumption', label: 'Misleading assumption' }, { value: 'insufficient_evidence', label: 'Insufficient evidence / abstention' },
  { value: 'conflicting_sources', label: 'Conflicting sources (only if present)' }, { value: 'citation_sensitive', label: 'Citation-sensitive' }, { value: 'retrieval_hard', label: 'Retrieval-hard / distractors' }
];
const starter = JSON.stringify([
  { id: 'policy-1', text: 'Eligible delayed shipments may receive reimbursement up to ₹25,000 after review. Claims must be filed within 30 days of delivery.' },
  { id: 'policy-2', text: 'Reimbursement excludes delays caused by an incorrect delivery address supplied by the recipient. The claim must include the shipment ID and proof of delivery.' }
], null, 2);
function loadSource(): string { try { return localStorage.getItem('synapse.syntheticSource') || starter; } catch { return starter; } }
function loadCandidates(): Candidate[] { try { const value: unknown = JSON.parse(localStorage.getItem('synapse.syntheticCandidates') || '[]'); if (!Array.isArray(value)) return []; return value.filter((c): c is Candidate => !!c && typeof c === 'object' && typeof c.id === 'string' && typeof c.question === 'string' && typeof c.reference_answer === 'string' && Array.isArray(c.evidence_ids) && (c.reviewStatus === 'unverified' || c.reviewStatus === 'approved' || c.reviewStatus === 'rejected') && typeof c.strategy === 'string' && strategies.some(strategy => strategy.value === c.strategy) && (c.expected_behavior === 'answer' || c.expected_behavior === 'abstain') && (c.difficulty === 'easy' || c.difficulty === 'medium' || c.difficulty === 'hard') && typeof c.challenge === 'string' && typeof c.provenance === 'string'); } catch { return []; } }
function exportCandidates(candidates: Candidate[]) { const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), status: 'AI-generated candidates; review required; not a validated benchmark', candidates }, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'synapse-synthetic-candidates.json'; a.click(); URL.revokeObjectURL(url); }
export default function AIBenchmarkGenerator({ onImport }: { onImport: (dataset: Dataset) => void }) {
  const [source, setSource] = useState(loadSource); const [count, setCount] = useState(5); const [strategy, setStrategy] = useState<Strategy>('adversarial_answerable'); const [difficulty, setDifficulty] = useState<'easy'|'medium'|'hard'>('medium');
  const [candidates, setCandidates] = useState<Candidate[]>(loadCandidates); const [conflictConfirmed, setConflictConfirmed] = useState<Record<string, boolean>>({}); const [model, setModel] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [status, setStatus] = useState('');
  const parsedPassages = useMemo(() => { try { const p = JSON.parse(source); return Array.isArray(p) ? p as Passage[] : []; } catch { return []; } }, [source]);
  const approvedCount = candidates.filter(c => c.reviewStatus === 'approved').length;
  const rejectedCount = candidates.filter(c => c.reviewStatus === 'rejected').length;
  const reviewedCount = approvedCount + rejectedCount;
  const pendingCount = candidates.filter(c => c.reviewStatus === 'unverified').length;
  useEffect(() => { try { localStorage.setItem('synapse.syntheticSource', source); localStorage.setItem('synapse.syntheticCandidates', JSON.stringify(candidates)); } catch { setError('Browser storage could not persist the synthetic source or review status. Export candidate JSON before leaving this page.'); } }, [source, candidates]);
  async function generate() {
    setError(''); setStatus(''); setCandidates([]); setConflictConfirmed({}); setModel('');
    let passages: Passage[];
    try {
      const parsed: unknown = JSON.parse(source);
      if (!Array.isArray(parsed) || parsed.length < 1 || parsed.length > 20) throw new Error('Enter a JSON array containing 1–20 passages.');
      passages = parsed as Passage[];
      if (passages.some(p => !p || typeof p.id !== 'string' || !p.id.trim() || typeof p.text !== 'string' || !p.text.trim())) throw new Error('Every passage needs a non-empty string id and text.');
      if (new Set(passages.map(p => p.id)).size !== passages.length) throw new Error('Passage IDs must be unique.');
      if (passages.reduce((n, p) => n + p.text.length, 0) > 40000) throw new Error('Passage text exceeds 40,000 characters.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Invalid source JSON.'); return; }
    setBusy(true);
    try {
      const response = await fetch('/api/generate-benchmark', { method: 'POST', headers: aiHeaders(), body: JSON.stringify({ passages, count, strategy, difficulty }) });
      const data = await response.json() as { error?: string; model?: string; candidates?: Omit<Candidate, 'reviewStatus' | 'provenance'>[] };
      if (!response.ok) throw new Error(data.error || `Benchmark request failed (${response.status}).`);
      if (!Array.isArray(data.candidates) || !data.candidates.length) throw new Error('The server returned no valid candidates.');
      const allowed = new Set(passages.map(p => p.id));
      const validated = data.candidates.map((c, i): Candidate => {
        if (!c || typeof c.question !== 'string' || typeof c.reference_answer !== 'string' || !Array.isArray(c.evidence_ids) || c.evidence_ids.some(id => !allowed.has(id)) || !['answer','abstain'].includes(c.expected_behavior) || !strategies.some(s => s.value === c.strategy) || !['easy','medium','hard'].includes(c.difficulty) || typeof c.challenge !== 'string') throw new Error(`Candidate ${i + 1} failed validation. No candidates were loaded.`);
        if (c.expected_behavior === 'answer' && (!c.reference_answer.trim() || c.evidence_ids.length === 0)) throw new Error(`Candidate ${i + 1} needs a reference-answer draft and valid evidence IDs.`);
        if (c.expected_behavior === 'abstain' && c.evidence_ids.length !== 0) throw new Error(`Abstention candidate ${i + 1} must not claim evidence IDs as supporting answers.`);
        return { ...c, id: typeof c.id === 'string' && c.id ? c.id : `candidate-${i+1}`, provenance: `OpenAI model ${data.model || 'configured model'}; generated ${new Date().toISOString()}; source passage IDs: ${passages.map(p=>p.id).join(', ')}`, reviewStatus: 'unverified' };
      });
      setCandidates(validated); setModel(data.model || 'Configured model'); setStatus('Candidates are AI-generated and unverified. Review and edit each candidate before approving it. Conflicting-source candidates require manual confirmation that the cited passages genuinely conflict.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not generate candidates.'); }
    finally { setBusy(false); }
  }
  function patchCandidate(id: string, patch: Partial<Candidate>) { setCandidates(old => old.map(c => c.id === id ? { ...c, ...patch, reviewStatus: 'unverified' } : c)); setConflictConfirmed(old => ({ ...old, [id]: false })); }
  function review(candidate: Candidate, reviewStatus: Candidate['reviewStatus']) {
    const allowed = new Set(parsedPassages.map(p => p.id));
    if (reviewStatus === 'approved') {
      if (!candidate.question.trim() || (candidate.expected_behavior === 'answer' && (!candidate.reference_answer.trim() || !candidate.evidence_ids.length)) || (candidate.expected_behavior === 'abstain' && candidate.evidence_ids.length > 0) || candidate.evidence_ids.some(id => !allowed.has(id))) { setError('Cannot approve: check the question, reference answer, abstention behavior, and evidence IDs against the supplied passages.'); return; }
      if (candidate.strategy === 'insufficient_evidence' && candidate.expected_behavior !== 'abstain') { setError('Insufficient-evidence strategy must expect abstention.'); return; }
      if (candidate.strategy === 'multi_passage' && candidate.evidence_ids.length < 2) { setError('Multi-passage cases require at least two expected evidence IDs.'); return; }
      if (candidate.strategy === 'conflicting_sources' && candidate.evidence_ids.length < 2) { setError('Conflicting-source cases require at least two source IDs and human confirmation.'); return; }
      if (candidate.strategy === 'conflicting_sources' && !conflictConfirmed[candidate.id]) { setError('Before approval, confirm that the supplied passages genuinely conflict about the same subject.'); return; }
    }
    setError(''); setCandidates(old => old.map(c => c.id === candidate.id ? { ...c, reviewStatus } : c));
  }
  function importApproved() {
    let passages: Passage[]; try { passages = JSON.parse(source) as Passage[]; } catch { setError('Source JSON is no longer valid.'); return; }
    const chosen = candidates.filter(c => c.reviewStatus === 'approved'); if (!chosen.length) { setError('Approve at least one candidate before importing.'); return; }
    const allowed = new Set(passages.map(p => p.id));
    if (chosen.some(c => c.evidence_ids.some(id => !allowed.has(id)) || (c.expected_behavior === 'answer' && (!c.reference_answer.trim() || !c.evidence_ids.length)) || (c.expected_behavior === 'abstain' && c.evidence_ids.length > 0) || (c.strategy === 'insufficient_evidence' && c.expected_behavior !== 'abstain') || (c.strategy === 'multi_passage' && c.evidence_ids.length < 2) || (c.strategy === 'conflicting_sources' && c.evidence_ids.length < 2))) { setError('An approved candidate no longer matches the current source data or strategy rules. Re-review and approve it again.'); return; }
    const cases: TestCase[] = chosen.map((c, i) => ({
      id: `synthetic-${Date.now().toString(36)}-${i + 1}`, question: c.question,
      generated_answer: '', ...(c.expected_behavior === 'answer' ? { reference_answer: c.reference_answer } : {}),
      retrieved_contexts: passages.map(p => ({ id: p.id, text: p.text })), expected_evidence: c.evidence_ids, citations: [],
      synthetic: { strategy: c.strategy, difficulty: c.difficulty, challenge: c.challenge, provenance: c.provenance, reviewStatus: 'approved', expectedBehavior: c.expected_behavior }
    }));
    onImport({ id: `dataset-synthetic-${Date.now()}`, name: `Reviewed synthetic tests — ${new Date().toLocaleDateString()}`, cases });
  }
  return <section className="ai-benchmark page-section">
    <div className="page-heading"><div><div className="eyebrow">OPTIONAL SERVER-SIDE AI</div><h1>Synthetic testing lab</h1><p>Generate evidence-grounded challenge cases, review them, then import only the cases you approve.</p></div><span className="pill warning">Unverified until reviewed</span></div>
    <div className="info-note"><b>Honest scope:</b> source passages are sent to OpenAI when you generate. All outputs are drafts, not a validated benchmark. Conflicting-source cases must be manually checked against the actual source text. API key remains server-side.</div>
    <AccessTokenField />
    <label className="field-label" htmlFor="benchmark-source">Source passages (JSON array)</label><textarea id="benchmark-source" className="benchmark-source" value={source} onChange={e => { setSource(e.target.value); setCandidates(old => old.map(c => ({ ...c, reviewStatus: 'unverified' }))); setConflictConfirmed({}); }} spellCheck={false} aria-describedby="benchmark-format" />
    <small id="benchmark-format">Unique passage IDs and non-empty text. Maximum 20 passages / 40,000 text characters.</small>
    <div className="benchmark-controls"><label>Strategy<select value={strategy} onChange={e=>setStrategy(e.target.value as Strategy)}>{strategies.map(s=><option key={s.value} value={s.value}>{s.label}</option>)}</select></label><label>Difficulty<select value={difficulty} onChange={e=>setDifficulty(e.target.value as typeof difficulty)}>{['easy','medium','hard'].map(d=><option key={d}>{d}</option>)}</select></label><label>Count<select value={count} onChange={e=>setCount(Number(e.target.value))}>{[1,2,3,4,5,6,7,8].map(n=><option key={n} value={n}>{n}</option>)}</select></label><button className="btn primary" disabled={busy} onClick={generate}>{busy ? 'Generating…' : 'Generate challenge cases'}</button></div>
    {error && <div className="ai-error" role="alert">{error}</div>}{status && <div className="info-note" role="status">{status}<small> Model: {model}.</small></div>}
    {candidates.length > 0 && <><div className="section-head"><div><h2>Review candidates</h2><p>{candidates.length} generated · {reviewedCount} reviewed · {pendingCount} pending · {approvedCount} approved · {rejectedCount} rejected. Approval is a human label, not independent validation.</p></div><div className="button-row"><button className="btn secondary" onClick={()=>exportCandidates(candidates)}>Export candidates JSON</button><button className="btn primary" onClick={importApproved}>Import approved ({approvedCount})</button></div></div>
      <div className="candidate-list">{candidates.map(candidate => <article className="candidate-card" key={candidate.id}>
        <div className="candidate-meta"><span className={`pill ${candidate.reviewStatus==='approved'?'success':candidate.reviewStatus==='rejected'?'danger':'warning'}`}>{candidate.reviewStatus}</span><span className="pill">{candidate.difficulty}</span><span className="pill">{strategies.find(s=>s.value===candidate.strategy)?.label ?? candidate.strategy}</span></div>
        <label className="field-label">Question<textarea rows={2} value={candidate.question} onChange={e=>patchCandidate(candidate.id,{question:e.target.value})}/></label>
        <label className="field-label">Strategy<select value={candidate.strategy} onChange={e=>patchCandidate(candidate.id,{strategy:e.target.value as Strategy})}>{strategies.map(s=><option key={s.value} value={s.value}>{s.label}</option>)}</select></label>
        <label className="field-label">Difficulty<select value={candidate.difficulty} onChange={e=>patchCandidate(candidate.id,{difficulty:e.target.value as Candidate['difficulty']})}>{['easy','medium','hard'].map(d=><option key={d}>{d}</option>)}</select></label>
        <label className="field-label">Expected behavior<select value={candidate.expected_behavior} onChange={e=>patchCandidate(candidate.id,{expected_behavior:e.target.value as Candidate['expected_behavior']})}><option value="answer">Answer from evidence</option><option value="abstain">Abstain / explain missing evidence</option></select></label>
        {candidate.expected_behavior==='answer' && <label className="field-label">Reference-answer draft<textarea rows={2} value={candidate.reference_answer} onChange={e=>patchCandidate(candidate.id,{reference_answer:e.target.value})}/></label>}
        <label className="field-label">Expected evidence IDs (comma-separated; must exist in sources)<input value={candidate.evidence_ids.join(', ')} onChange={e=>patchCandidate(candidate.id,{evidence_ids:e.target.value.split(',').map(x=>x.trim()).filter(Boolean)})}/></label>
        <label className="field-label">Why this is challenging<textarea rows={2} value={candidate.challenge} onChange={e=>patchCandidate(candidate.id,{challenge:e.target.value})}/></label>
        <p><strong>Provenance:</strong> {candidate.provenance}</p><p><strong>Source passages:</strong> {parsedPassages.filter(p=>candidate.evidence_ids.includes(p.id)).map(p=>p.id).join(', ') || (candidate.expected_behavior==='abstain'?'No answer-supporting evidence claimed.':'No valid evidence IDs selected.')}</p>
        {candidate.strategy==='conflicting_sources'&&<div className="info-note">Manual verification required: ensure these passages actually conflict about the same subject. The generator cannot establish a real contradiction just by labeling it.<label className="check-row"><input type="checkbox" checked={!!conflictConfirmed[candidate.id]} onChange={e=>setConflictConfirmed(old=>({...old,[candidate.id]:e.target.checked}))}/><span><b>I verified the source passages genuinely conflict</b><small>Required before approving this case.</small></span></label></div>}
        <div className="candidate-actions"><button className="btn secondary compact" onClick={()=>review(candidate,'approved')}>Approve</button><button className="btn secondary compact" onClick={()=>review(candidate,'rejected')}>Reject</button><button className="btn secondary compact" onClick={()=>review(candidate,'unverified')}>Reset review</button></div>
      </article>)}</div></>}
  </section>;
}
