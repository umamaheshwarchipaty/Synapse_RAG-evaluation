import { useState } from 'react';
import { getAccessToken, setAccessToken } from '../lib/access';
export default function AccessTokenField() {
  const [value, setValue] = useState(getAccessToken);
  return <div className="access-token-field"><label className="field-label" htmlFor="synapse-access-token">AI access token</label>
    <input id="synapse-access-token" type="password" autoComplete="off" value={value} placeholder="Required for AI features" onChange={e => { setValue(e.target.value); setAccessToken(e.target.value); }} />
    <small>Matches the server-side SYNAPSE_ACCESS_TOKEN. Kept only for this browser tab (sessionStorage).</small></div>;
}
