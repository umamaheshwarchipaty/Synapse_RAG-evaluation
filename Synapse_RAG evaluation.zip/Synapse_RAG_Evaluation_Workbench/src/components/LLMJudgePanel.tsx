import { useState } from 'react';
import type { TestCase } from '../types';
import { aiHeaders } from '../lib/access';
import AccessTokenField from './AccessTokenField';
type Judgment = { answer_correctness: 'correct'|'partially_correct'|'incorrect'|'uncertain'; evidence_support: 'supported'|'partially_supported'|'unsupported'|'uncertain'; rationale: string; supporting_evidence_ids: string[] };
export default function LLMJudgePanel({ testCase }: { testCase: TestCase }) {
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [model, setModel] = useState(''); const [judgment, setJudgment] = useState<Judgment|null>(null);
  async function judge() {
    setBusy(true); setError(''); setJudgment(null);
    try {
      const response = await fetch('/api/judge-answer', { method: 'POST', headers: aiHeaders(), body: JSON.stringify({ question: testCase.question, answer: testCase.generated_answer, reference_answer: testCase.reference_answer, contexts: testCase.retrieved_contexts }) });
      const data = await response.json() as { error?: string; model?: string; judgment?: Judgment };
      if (!response.ok) throw new Error(data.error || `Judge request failed (${response.status}).`);
      if (!data.judgment || !Array.isArray(data.judgment.supporting_evidence_ids)) throw new Error('The server returned an invalid judgment.');
      setJudgment(data.judgment); setModel(data.model || 'Configured model');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not judge this answer.'); }
    finally { setBusy(false); }
  }
  return <section className="llm-judge"><div className="section-head"><div><h3>Optional LLM judge</h3><p>Server-side semantic review; advisory only, not a calibrated score.</p></div><button className="btn secondary compact" disabled={busy || !testCase.generated_answer.trim()} onClick={judge}>{busy ? 'Judging…' : 'Judge this answer'}</button></div>
    <AccessTokenField />
    {!testCase.generated_answer.trim() && <small>Add a generated answer to this case before requesting a judgment.</small>}
    {error && <div className="ai-error" role="alert">{error}</div>}
    {judgment && <div className="judge-result"><div><b>Answer correctness</b><span className="pill">{judgment.answer_correctness.replaceAll('_',' ')}</span></div><div><b>Evidence support</b><span className="pill">{judgment.evidence_support.replaceAll('_',' ')}</span></div><p>{judgment.rationale}</p><small>Model: {model}</small>{judgment.supporting_evidence_ids.length>0&&<p><b>Supporting evidence IDs:</b> {judgment.supporting_evidence_ids.join(', ')}</p>}</div>}
  </section>;
}
