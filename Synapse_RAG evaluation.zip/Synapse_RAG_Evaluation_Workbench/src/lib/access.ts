const KEY = 'synapse.accessToken';
/** The access token lives in sessionStorage only (cleared when the tab closes) and is never written to localStorage. */
export function getAccessToken(): string { try { return sessionStorage.getItem(KEY) ?? ''; } catch { return ''; } }
export function setAccessToken(value: string): void { try { value ? sessionStorage.setItem(KEY, value) : sessionStorage.removeItem(KEY); } catch { /* storage unavailable */ } }
export function aiHeaders(): Record<string, string> {
  const token = getAccessToken();
  return { 'Content-Type': 'application/json', ...(token ? { 'x-synapse-access-token': token } : {}) };
}
