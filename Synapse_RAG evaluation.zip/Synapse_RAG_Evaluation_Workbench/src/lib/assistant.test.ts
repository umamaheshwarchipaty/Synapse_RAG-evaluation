import { describe, expect, it } from 'vitest';
import { answerAssistant } from './assistant';
import type { Dataset, Run } from '../types';

const dataset: Dataset = { id: 'd1', name: 'Test data', cases: [{ id: 'CASE-1', question: 'What is the limit?', generated_answer: 'Limit is 10', reference_answer: 'Limit is 10', retrieved_contexts: [{ id: 'CTX-1', text: 'The limit is 10', relevant: true }], expected_evidence: ['CTX-1'] }] };
const run: Run = { id: 'r1', name: 'Run A', timestamp: '2026-01-01T00:00:00.000Z', datasetId: 'd1', datasetName: 'Test data', config: { name: 'test', k: 1, requireCitations: false, metrics: ['retrieval'] }, results: [{ caseId: 'CASE-1', retrieval: { score: 1, verdict: 'pass', explanation: 'label match', formula: 'precision@k' }, correctness: { score: 1, verdict: 'pass', explanation: 'token overlap', formula: 'F1' }, citations: { score: null, verdict: 'unavailable', explanation: 'not supplied', formula: 'n/a' }, unsupported: { score: 0, verdict: 'pass', explanation: 'overlap', formula: 'heuristic' }, failures: [], diagnosis: 'none', suggestedAction: 'inspect', findings: [{ id: 'f1', category: 'test', severity: 'low', summary: 'Example finding', basis: 'rule', evidenceIds: ['CTX-1'], method: 'deterministic', nextStep: 'Inspect passage' }] }], sample: false, caseIds: ['CASE-1'] };

describe('local context assistant', () => {
  it('explains metrics without inventing application state', () => {
    expect(answerAssistant('Explain citation accuracy', dataset, run, [run]).text).toContain('valid ID');
  });
  it('answers a case question with actual findings and evidence IDs', () => {
    const answer = answerAssistant('Why did CASE-1 fail?', dataset, run, [run]);
    expect(answer.text).toContain('CASE-1');
    expect(answer.text).toContain('Example finding');
    expect(answer.references).toContain('CTX-1');
  });
  it('reports no-run state instead of fabricating scores', () => {
    expect(answerAssistant('summarize the score', dataset, undefined, []).text).toContain('no saved evaluation run');
  });
  it('does not mistake an operational failure question for a metric glossary request', () => {
    const answer = answerAssistant('Why did retrieval fail?', dataset, run, [run]);
    expect(answer.text).toContain('There are 1 saved run(s)');
    expect(answer.text).not.toContain('Retrieval precision@k is');
  });
  it('still explains a metric when the user explicitly asks for its meaning', () => {
    expect(answerAssistant('Explain retrieval metric', dataset, run, [run]).text).toContain('Retrieval precision@k');
  });
  it('declines unsupported arbitrary questions honestly', () => {
    expect(answerAssistant('What will happen next year?', dataset, run, [run]).text).toContain('could not answer');
  });
  it('summarizes actual dataset counts and missing references', () => {
    expect(answerAssistant('How many cases are in this dataset?', dataset, run, [run]).text).toContain('contains 1 cases');
  });
});
