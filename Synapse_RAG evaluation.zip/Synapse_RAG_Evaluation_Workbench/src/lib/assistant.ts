import type { Dataset, Run } from '../types';

export type AssistantReply = { text: string; source: 'deterministic-local'; references: string[] };

const metricHelp: Record<string, string> = {
  precision: 'Retrieval precision@k is the fraction of retrieved passages in the first k positions that have an explicit relevant=true label. If labels are missing, the app may use expected-evidence coverage instead; these are different signals.',
  recall: 'Recall asks how much of the known relevant evidence was retrieved. Synapse does not calculate recall unless the complete relevant-evidence universe is known, so unavailable is more honest than guessing.',
  coverage: 'Expected-evidence coverage is the fraction of supplied expected evidence IDs that appear in retrieved context IDs. It measures ID coverage, not semantic support.',
  f1: 'Answer token F1 compares normalized token overlap between the generated and reference answers. It is a lexical baseline, not a factuality or semantic-equivalence judge.',
  citation: 'Citation accuracy checks whether citation context IDs resolve to retrieved context IDs. A valid ID only proves that the passage exists; it does not prove that the passage supports the claim.',
  grounding: 'The unsupported-answer signal is a heuristic based on lexical overlap with retrieved context. It cannot establish semantic faithfulness or detect every contradiction.'
};

export function answerAssistant(question: string, dataset: Dataset | undefined, run: Run | undefined, allRuns: Run[]): AssistantReply {
  const q = question.trim().toLowerCase();
  if (!q) return { text: 'Ask about a metric, a case ID, the selected run, or the next debugging step.', source: 'deterministic-local', references: [] };
  for (const [term, help] of Object.entries(metricHelp)) {
    const aliases: Record<string, string[]> = { precision: ['precision', 'retrieval'], recall: ['recall'], coverage: ['coverage', 'expected evidence'], f1: ['f1', 'correctness', 'reference answer'], citation: ['citation', 'cite'], grounding: ['grounding', 'unsupported', 'faithfulness'] };
    const matchedAliases = (aliases[term] ?? [term]).filter(alias => q.includes(alias));
    const asksForMetricHelp = /\b(what is|explain|meaning|mean|metric|formula|calculate|how does|define)\b/.test(q)
      || matchedAliases.some(alias => q.trim() === alias);
    // Do not let a short operational question such as "why did retrieval fail?"
    // get intercepted by a metric glossary entry before run/case context is checked.
    if (matchedAliases.length > 0 && asksForMetricHelp) {
      return { text: help, source: 'deterministic-local', references: [] };
    }
  }
  if (!run) return { text: 'There is no saved evaluation run selected yet, so I cannot report case findings or scores. Open Run Evaluation and execute a dataset first. I can still explain the supported metrics.', source: 'deterministic-local', references: [] };
  const caseResult = run.results.find(r => q.includes(r.caseId.toLowerCase()));
  if (caseResult) {
    const findings = caseResult.findings ?? [];
    const refs = [caseResult.caseId, ...findings.flatMap(f => f.evidenceIds)];
    return { text: `Case ${caseResult.caseId} in run “${run.name}”: ${caseResult.failures.length ? caseResult.failures.join(', ') : 'no configured deterministic failure was triggered'}. Retrieval: ${caseResult.retrieval.score === null ? 'unavailable' : `${Math.round(caseResult.retrieval.score * 100)}%`}; answer/reference lexical F1: ${caseResult.correctness.score === null ? 'unavailable' : `${Math.round(caseResult.correctness.score * 100)}%`}; citation ID validity: ${caseResult.citations.score === null ? 'unavailable' : `${Math.round(caseResult.citations.score * 100)}%`}. ${findings.length ? `Findings: ${findings.map(f => `${f.category} (${f.method}; ${f.severity}) — ${f.summary}. Next: ${f.nextStep}`).join(' ')}` : 'No structured finding was triggered. That does not prove semantic correctness.'}`, source: 'deterministic-local', references: [...new Set(refs)] };
  }
  if (q.includes('dataset') || q.includes('how many cases') || q.includes('cases')) {
    if (!dataset) return { text: 'No dataset is selected. Choose a dataset in the Datasets or Run Evaluation page.', source: 'deterministic-local', references: [] };
    const total = dataset.cases.length;
    const missingRef = dataset.cases.filter(c => !c.reference_answer?.trim()).length;
    const missingContext = dataset.cases.filter(c => !c.retrieved_contexts.length).length;
    return { text: `Selected dataset “${dataset.name}” contains ${total} cases. ${missingRef} case(s) lack a reference answer and ${missingContext} case(s) have no retrieved contexts. ${dataset.sample ? 'This is labeled sample data.' : 'This is a user dataset.'}`, source: 'deterministic-local', references: dataset.cases.map(c => c.id).slice(0, 20) };
  }
  if (q.includes('run') || q.includes('score') || q.includes('result') || q.includes('compare') || (q.includes('retrieval') && (q.includes('fail') || q.includes('why')))) {
    return { text: `There are ${allRuns.length} saved run(s). ${run ? `Selected run “${run.name}” evaluated ${run.results.length} cases on dataset “${run.datasetName}”. Its findings are based on the configured deterministic/heuristic checks; they are not LLM judgments.` : 'No run is selected.'} Ask about a specific case ID to inspect its available metrics and findings.`, source: 'deterministic-local', references: run ? [run.id, ...run.caseIds.slice(0, 10)] : [] };
  }
  return { text: 'I could not answer that from the available local rules and selected application data. Try “explain citation accuracy”, “how many cases are in this dataset?”, “why did CASE_ID fail?”, or “summarize this run”. This assistant is deterministic local guidance, not a generative LLM.', source: 'deterministic-local', references: [] };
}
