import {describe,it,expect} from 'vitest';import{evaluateCase,evaluateDataset,aggregate,makeRun as makeRunForTest,evaluateCounterfactual,compareRunCompatibility}from'./evaluator';import type{TestCase,EvalConfig}from'../types';
const cfg:EvalConfig={name:'test',k:4,requireCitations:true,metrics:['retrieval','correctness','citations','unsupported']};
const base:TestCase={id:'T1',question:'What is the limit?',retrieved_contexts:[{id:'a',text:'reimbursement limit 25000',relevant:true},{id:'b',text:'weather delay details',relevant:false},{id:'c',text:'address details',relevant:false},{id:'d',text:'contact support',relevant:true}],generated_answer:'The reimbursement limit is 25000',reference_answer:'The reimbursement limit is 25000',expected_evidence:['a'],citations:[{context_id:'a',claim:'limit is 25000'}]};
describe('Synapse deterministic evaluation',()=>{it('calculates Precision@4 as 0.5 for two relevant of four',()=>{const r=evaluateCase(base,cfg);expect(r.retrieval.score).toBe(0.5)});it('marks retrieval as unavailable without labels or expected evidence',()=>{const c={...base,retrieved_contexts:[{id:'a',text:'some context'}],expected_evidence:[]};expect(evaluateCase(c,cfg).retrieval.verdict).toBe('unavailable')});it('flags invalid citation IDs',()=>{const c={...base,citations:[{context_id:'not-there',claim:'x'}]};expect(evaluateCase(c,cfg).citations.verdict).toBe('fail');expect(evaluateCase(c,cfg).failures).toContain('Invalid citation')});it('handles missing reference answer honestly',()=>{expect(evaluateCase({...base,reference_answer:undefined},cfg).correctness.verdict).toBe('unavailable')});it('flags answers with no context',()=>{const r=evaluateCase({...base,retrieved_contexts:[]},cfg);expect(r.unsupported.verdict).toBe('fail');expect(r.failures).toContain('Unsupported claim')});it('rejects empty datasets',()=>{expect(()=>evaluateDataset([],cfg)).toThrow(/empty/i)});it('rejects malformed case fields',()=>{expect(()=>evaluateDataset([{...base,question:''}],cfg)).toThrow(/question/i)});it('aggregate excludes unavailable scores',()=>{const a=evaluateCase(base,cfg);const b=evaluateCase({...base,reference_answer:undefined},cfg);expect(aggregate([a,b],'correctness')).toBe(a.correctness.score)});it('detects missing citations when required',()=>{expect(evaluateCase({...base,citations:[]},cfg).citations.verdict).toBe('fail')});});

describe('evidence-linked diagnostics and configuration',()=>{
 it('does not calculate or flag metrics that were not selected',()=>{
  const r=evaluateCase(base,{...cfg,metrics:['correctness']});
  expect(r.correctness.verdict).toBe('pass');
  expect(r.retrieval.verdict).toBe('unavailable');
  expect(r.citations.verdict).toBe('unavailable');
  expect(r.failures).not.toContain('Retrieval miss');
  expect(r.findings).toEqual([]);
 });
 it('does not count partially labeled passages as irrelevant',()=>{
  const c={...base,retrieved_contexts:[{id:'a',text:'reimbursement limit 25000',relevant:true},{id:'b',text:'weather'}],expected_evidence:[]};
  expect(evaluateCase(c,cfg).retrieval.verdict).toBe('unavailable');
 });
 it('matches expected evidence by context ID, not incidental text',()=>{
  const c={...base,retrieved_contexts:[{id:'ctx-1',text:'The phrase evidence-42 appears here'}],expected_evidence:['evidence-42']};
  expect(evaluateCase(c,cfg).retrieval.score).toBe(0);
 });
 it('returns a finding linked to an invalid citation',()=>{
  const r=evaluateCase({...base,citations:[{context_id:'missing-id',claim:'limit is 25000'}]},cfg);
  expect(r.findings?.some(f=>f.category==='Citation ID does not resolve'&&f.evidenceIds.includes('missing-id'))).toBe(true);
 });
 it('rejects duplicate case IDs and duplicate context IDs',()=>{
  expect(()=>evaluateDataset([base,{...base}],cfg)).toThrow(/duplicate test case id/i);
  expect(()=>evaluateDataset([{...base,retrieved_contexts:[{id:'same',text:'a'},{id:'same',text:'b'}]}],cfg)).toThrow(/duplicate context id/i);
 });
 it('rejects an invalid retrieval cutoff',()=>{
  expect(()=>evaluateDataset([base],{...cfg,k:0})).toThrow(/cutoff/i);
 });
 it('marks a substantive response as failure to abstain for synthetic insufficient-evidence cases',()=>{
  const c={...base,generated_answer:'The carrier was Acme.',reference_answer:undefined,expected_evidence:[],synthetic:{strategy:'insufficient_evidence',difficulty:'hard',challenge:'No carrier is named.',provenance:'mock',reviewStatus:'approved' as const,expectedBehavior:'abstain' as const}};
  const r=evaluateCase(c,cfg); expect(r.failures).toContain('Failure to abstain'); expect(r.findings?.some(f=>f.category==='Failure to abstain')).toBe(true);
 });
 it('does not score missing output as successful abstention',()=>{
  const c={...base,generated_answer:'',reference_answer:undefined,expected_evidence:[],synthetic:{strategy:'insufficient_evidence',difficulty:'hard',challenge:'No carrier is named.',provenance:'mock',reviewStatus:'approved' as const,expectedBehavior:'abstain' as const}};
  expect(evaluateCase(c,cfg).unsupported.verdict).toBe('unavailable');
 });
 it('recognizes explicit abstention phrases without requiring citations',()=>{
  const c={...base,generated_answer:'I cannot answer from the provided evidence.',reference_answer:undefined,expected_evidence:[],citations:[],synthetic:{strategy:'insufficient_evidence',difficulty:'hard',challenge:'No carrier is named.',provenance:'mock',reviewStatus:'approved' as const,expectedBehavior:'abstain' as const}};
  const r=evaluateCase(c,cfg); expect(r.unsupported.verdict).toBe('pass'); expect(r.failures).not.toContain('Missing citation'); expect(r.failures).not.toContain('Insufficient information to judge');
 });
});

describe('saved-run dataset fingerprint',()=>{
 it('stores a stable fingerprint for identical dataset content',()=>{
  const a=makeRunForTest('a','dataset-1','dataset',[base],cfg);
  const b=makeRunForTest('b','dataset-1','dataset',[base],cfg);
  expect(a.datasetFingerprint).toBe(b.datasetFingerprint);
 });
 it('changes the fingerprint when dataset content changes',()=>{
  const a=makeRunForTest('a','dataset-1','dataset',[base],cfg);
  const b=makeRunForTest('b','dataset-1','dataset',[{...base,generated_answer:'changed answer'}],cfg);
  expect(a.datasetFingerprint).not.toBe(b.datasetFingerprint);
 });
});


describe('policy consistency and counterfactual experiments',()=>{
 it('reports a required missing citation even when citation scoring is disabled',()=>{
  const r=evaluateCase({...base,citations:[]},{...cfg,metrics:['correctness'],requireCitations:true});
  expect(r.citations.verdict).toBe('unavailable');
  expect(r.failures).toContain('Missing citation');
  expect(r.findings?.some(f=>f.category==='Missing citation')).toBe(true);
 });
 it('changes retrieval metric when cutoff changes and preserves original case data',()=>{
  const before=JSON.stringify(base);
  const result=evaluateCounterfactual([base],{...cfg,k:1},'T1',{k:2});
  expect(result.changedVariables).toEqual(['k']);
  expect(result.baseline.retrieval.score).toBe(1);
  expect(result.candidate.retrieval.score).toBe(0.5);
  expect(JSON.stringify(base)).toBe(before);
 });
 it('rejects unknown cases in counterfactual experiments',()=>{
  expect(()=>evaluateCounterfactual([base],cfg,'NOPE',{k:2})).toThrow(/not found/i);
 });
 it('compares run compatibility across dataset and evaluation settings',()=>{
  const a=makeRunForTest('a','d','dataset',[base],cfg);
  const same=makeRunForTest('b','d','dataset',[base],cfg);
  expect(compareRunCompatibility(a,same).compatible).toBe(true);
  const changed=makeRunForTest('c','d','dataset',[base],{...cfg,k:2});
  expect(compareRunCompatibility(a,changed).cutoff).toBe(false);
  expect(compareRunCompatibility(a,changed).compatible).toBe(false);
 });
});
