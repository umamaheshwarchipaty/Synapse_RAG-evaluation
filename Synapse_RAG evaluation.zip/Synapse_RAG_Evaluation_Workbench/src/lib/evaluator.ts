import type { TestCase, MetricResult, CaseResult, EvalConfig, Run, DiagnosticFinding } from '../types';

const norm = (s: string) => s.toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}₹]+/gu, ' ').trim().replace(/\s+/g, ' ');
const tokens = (s: string) => norm(s).split(' ').filter(Boolean);
const pct = (n: number) => Math.round(n * 1000) / 10;

/** Lexical baseline over unique normalized tokens. This is not semantic entailment. */
export function tokenF1(a: string, b: string): number {
  const aa = new Set(tokens(a));
  const bb = new Set(tokens(b));
  if (!aa.size || !bb.size) return 0;
  let hit = 0;
  aa.forEach(t => { if (bb.has(t)) hit++; });
  const precision = hit / aa.size;
  const recall = hit / bb.size;
  return precision + recall ? 2 * precision * recall / (precision + recall) : 0;
}

function metric(score: number | null, verdict: MetricResult['verdict'], explanation: string, formula: string): MetricResult {
  return { score, verdict, explanation, formula };
}
const unavailable = (why: string) => metric(null, 'unavailable', why, 'Not calculated');

export function evaluateCase(c: TestCase, config: EvalConfig): CaseResult {
  const failures: string[] = [];
  const findings: DiagnosticFinding[] = [];
  const contexts = c.retrieved_contexts ?? [];
  const k = Number.isFinite(config.k) ? Math.max(1, Math.floor(config.k)) : 1;
  const top = contexts.slice(0, k);
  const enabled = (key: string) => config.metrics.includes(key);
  const expectedAbstention = c.synthetic?.expectedBehavior === 'abstain';
  const explicitAbstention = /\b(cannot answer|can't answer|cannot determine|insufficient (?:information|evidence)|not enough (?:information|evidence)|i (?:must )?abstain|unable to answer|the sources? (?:do not|don't) say)\b/i.test(c.generated_answer ?? '');
  const addFinding = (finding: DiagnosticFinding) => findings.push(finding);

  let retrieval = unavailable('No relevance labels or expected evidence are available; retrieval relevance cannot be scored.');
  if (enabled('retrieval')) {
    const labeled = top.filter(x => typeof x.relevant === 'boolean');
    const allLabelsExist = top.length > 0 && top.every(x => typeof x.relevant === 'boolean');
    const evidenceIds = c.expected_evidence ?? [];
    let retrievalScore: number | null = null;
    let retrievalExplanation = 'No relevance labels or expected evidence are available; retrieval relevance cannot be scored.';
    let retrievalFormula = `Precision@${k} = relevant labeled passages / retrieved passages in top-k`;
    if (allLabelsExist) {
      const relevant = top.filter(x => x.relevant === true).length;
      retrievalScore = top.length ? relevant / top.length : 0;
      retrievalExplanation = `${relevant} of ${top.length} top-k passages are labeled relevant.`;
    } else if (evidenceIds.length) {
      const evidenceFound = evidenceIds.filter(id => top.some(x => x.id === id));
      retrievalScore = evidenceFound.length / evidenceIds.length;
      retrievalExplanation = `Found ${evidenceFound.length} of ${evidenceIds.length} expected evidence ID(s) in top-k passages.`;
      retrievalFormula = 'Expected-evidence coverage = expected evidence IDs found in top-k / expected evidence IDs';
    } else if (labeled.length) {
      retrievalExplanation = 'Some passages have relevance labels, but not every top-k passage is labeled; precision is unavailable to avoid treating missing labels as irrelevant.';
    }
    retrieval = metric(retrievalScore, retrievalScore === null ? 'unavailable' : retrievalScore >= 0.5 ? 'pass' : 'fail', retrievalExplanation, retrievalFormula);
    if (retrievalScore !== null && retrievalScore < 0.5) {
      failures.push('Retrieval miss');
      addFinding({ id: `${c.id}:retrieval`, category: 'Low retrieval relevance', severity: 'high', summary: 'The retrieval signal is below the 50% review threshold.', basis: retrievalExplanation, evidenceIds: top.filter(x => x.relevant === false).map(x => x.id), method: 'deterministic', nextStep: 'Inspect ranking, query rewriting, chunk boundaries, and whether expected evidence is indexed.' });
    }
    if (evidenceIds.length && !evidenceIds.some(id => top.some(x => x.id === id))) {
      addFinding({ id: `${c.id}:missing-evidence`, category: 'Missing expected evidence', severity: 'high', summary: 'None of the expected evidence IDs appear in the selected top-k passages.', basis: `Expected IDs: ${evidenceIds.join(', ')}. Retrieved IDs: ${top.map(x => x.id).join(', ') || '(none)'}.`, evidenceIds: evidenceIds, method: 'deterministic', nextStep: 'Check the indexed corpus, retrieval filters, and ranking configuration.' });
    }
  } else retrieval = unavailable('Retrieval metric was disabled in the run configuration.');

  let correctness = unavailable('No reference answer supplied. Lexical correctness cannot be determined.');
  if (enabled('correctness')) {
    if (!c.reference_answer?.trim()) correctness = unavailable('No reference answer supplied. Lexical correctness cannot be determined.');
    else {
      const s = tokenF1(c.generated_answer ?? '', c.reference_answer);
      correctness = metric(s, s >= 0.55 ? 'pass' : 'fail', `Token-overlap F1 is ${pct(s)}%. This measures lexical overlap, not factual truth.`, 'F1 = 2 × precision × recall / (precision + recall), using normalized unique tokens');
      if (s < 0.55) {
        failures.push('Answer/reference mismatch');
        addFinding({ id: `${c.id}:answer-mismatch`, category: 'Answer/reference mismatch', severity: 'medium', summary: 'The answer has low lexical overlap with the supplied reference.', basis: `Token F1 = ${pct(s)}%; threshold = 55%. Lexical mismatch can also occur for correct paraphrases.`, evidenceIds: [], method: 'heuristic', nextStep: 'Compare the answer with the reference manually; check whether this is a valid paraphrase or a substantive omission.' });
      }
    }
  } else correctness = unavailable('Answer/reference metric was disabled in the run configuration.');

  let citations = unavailable('Citation assessment unavailable: citations or a citation requirement were not supplied.');
  if (enabled('citations')) {
    const known = new Set(contexts.map(x => x.id));
    const cites = c.citations ?? [];
    const invalid = cites.filter(x => !known.has(x.context_id));
    if (config.requireCitations && !cites.length && !(expectedAbstention && explicitAbstention)) {
      citations = metric(0, 'fail', 'Citations are required, but the answer contains no citation records.', 'Valid citation ratio = citations resolving to retrieved context IDs / total citations');
      failures.push('Missing citation');
      addFinding({ id: `${c.id}:missing-citation`, category: 'Missing citation', severity: 'medium', summary: 'The run requires citations but this answer provides none.', basis: 'requireCitations=true and citations array is empty.', evidenceIds: [], method: 'deterministic', nextStep: 'Emit citation IDs from the retrieved context and validate each ID before returning the answer.' });
    } else if (cites.length) {
      const score = (cites.length - invalid.length) / cites.length;
      citations = metric(score, invalid.length ? 'fail' : 'review', invalid.length ? `${invalid.length} citation(s) point to nonexistent context IDs: ${invalid.map(x => x.context_id).join(', ')}.` : 'All citation IDs resolve to retrieved passages; claim support still needs semantic or human review.', 'Valid citation ratio = citations resolving to retrieved context IDs / total citations');
      if (invalid.length) {
        failures.push('Invalid citation');
        addFinding({ id: `${c.id}:invalid-citation`, category: 'Citation ID does not resolve', severity: 'high', summary: 'One or more citation IDs do not match a retrieved passage.', basis: `Invalid IDs: ${invalid.map(x => x.context_id).join(', ')}.`, evidenceIds: invalid.map(x => x.context_id), method: 'deterministic', nextStep: 'Check citation ID mapping and ensure generated citations use IDs from the retrieved context list.' });
      }
      for (const cite of cites.filter(x => known.has(x.context_id) && x.claim?.trim())) {
        const passage = contexts.find(x => x.id === cite.context_id)!;
        const overlap = tokenF1(cite.claim!, passage.text);
        if (overlap < 0.16) addFinding({ id: `${c.id}:claim-support:${cite.context_id}`, category: 'Claim support needs review', severity: 'medium', summary: `The cited passage has low lexical overlap with the associated claim (${pct(overlap)}% token F1).`, basis: `Claim: “${cite.claim}” Passage ID: ${cite.context_id}. This is a heuristic signal, not a semantic contradiction or proof of unsupported content.`, evidenceIds: [cite.context_id], method: 'heuristic', nextStep: 'Read the cited passage and verify whether it entails the specific claim; lexical overlap alone cannot decide support.' });
      }
    } else citations = unavailable('No citation records supplied and citations are not required for this run.');
  } else citations = unavailable('Citation metric was disabled in the run configuration.');

  // Citation policy is a run-level constraint even when the citation score is not selected.
  // Keep the metric unavailable, but do not silently ignore a required missing citation.
  if (config.requireCitations && !(c.citations?.length) && !findings.some(f => f.category === 'Missing citation') && !(expectedAbstention && explicitAbstention)) {
    failures.push('Missing citation');
    addFinding({ id: `${c.id}:missing-citation`, category: 'Missing citation', severity: 'medium', summary: 'The run requires citations but this answer provides none.', basis: 'requireCitations=true and citations array is empty; citation scoring may be disabled.', evidenceIds: [], method: 'deterministic', nextStep: 'Emit citation IDs from the retrieved context and validate each ID before returning the answer.' });
  }

  let unsupported = unavailable('Unsupported-answer heuristic was disabled in the run configuration.');
  if (enabled('unsupported')) {
    const answer = (c.generated_answer ?? '').trim();
    const hasEvidence = top.some(x => tokenF1(answer, x.text) >= 0.16);
    if (expectedAbstention) {
      if (!answer) unsupported = unavailable('No generated response supplied; abstention behavior cannot be evaluated yet.');
      else if (explicitAbstention) unsupported = metric(0, 'pass', 'The response matches a configured abstention phrase for this insufficient-evidence test. This is a lexical rule, not semantic verification.', 'Expected-abstention check: pass when response matches the configured abstention phrase pattern');
      else {
        unsupported = metric(1, 'fail', 'This case expects abstention because evidence is insufficient, but a substantive answer was returned.', 'Expected-abstention check: fail when a non-empty response does not match the configured abstention phrase pattern');
        failures.push('Failure to abstain');
        addFinding({ id: `${c.id}:failure-to-abstain`, category: 'Failure to abstain', severity: 'high', summary: 'A substantive answer was returned for a case labeled as requiring abstention.', basis: 'synthetic.expectedBehavior=abstain and the response did not match the explicit abstention phrase rule. This does not determine whether the answer is semantically correct.', evidenceIds: [], method: 'deterministic', nextStep: 'Inspect the source passages and consider an evidence sufficiency check before generating a factual answer.' });
      }
    } else if (!answer) {
      unsupported = metric(1, 'fail', 'Generated answer is empty; no answer was grounded in evidence.', 'Heuristic flag = 1 when answer is empty or no retrieved passage has token-overlap F1 ≥ 0.16');
      failures.push('Empty answer');
      addFinding({ id: `${c.id}:empty-answer`, category: 'Empty answer', severity: 'medium', summary: 'No generated answer was supplied.', basis: 'generated_answer is empty after trimming.', evidenceIds: [], method: 'deterministic', nextStep: 'Check whether generation failed or the dataset omitted the answer.' });
    } else if (!contexts.length || !hasEvidence) {
      const explanation = !contexts.length ? 'No retrieved context was provided for a non-empty answer.' : 'No top-k retrieved passage has sufficient token overlap with the answer; this is a heuristic warning, not semantic proof.';
      unsupported = metric(1, 'fail', explanation, 'Heuristic flag = 1 when no retrieved passage has token-overlap F1 ≥ 0.16');
      failures.push('Unsupported claim');
      addFinding({ id: `${c.id}:unsupported`, category: !contexts.length ? 'Missing retrieved evidence' : 'Low lexical grounding', severity: 'high', summary: !contexts.length ? 'The answer has no retrieved passages to ground it.' : 'No selected passage reaches the lexical-overlap threshold.', basis: explanation, evidenceIds: top.map(x => x.id), method: 'heuristic', nextStep: 'Inspect each factual claim against retrieved passages; consider abstaining or retrieving more evidence when support is missing.' });
    } else unsupported = metric(0, 'pass', 'At least one top-k passage overlaps lexically with the answer. This does not establish that every claim is supported.', 'Heuristic flag = 0 when any top-k passage has token-overlap F1 ≥ 0.16');
  }

  if (!failures.length && (!c.reference_answer?.trim() || !contexts.length) && !(expectedAbstention && explicitAbstention)) failures.push('Insufficient information to judge');
  const diagnosis = failures.length ? `Heuristic diagnosis: ${failures.join(', ').toLowerCase()}. Inspect the retrieved passages and claim-level evidence before treating this as a confirmed root cause.` : 'No deterministic failure rule triggered. Semantic claim support may still require human review.';
  const suggestedAction = findings[0]?.nextStep ?? 'Review a sample of claims manually and confirm the evaluator inputs and labels.';
  return { caseId: c.id, retrieval, correctness, citations, unsupported, failures, diagnosis, suggestedAction, findings };
}

export function evaluateDataset(cases: TestCase[], config: EvalConfig): CaseResult[] {
  if (!Array.isArray(cases) || cases.length === 0) throw new Error('Dataset is empty. Add at least one test case before running evaluation.');
  if (!Number.isFinite(config.k) || config.k < 1) throw new Error('Retrieval cutoff k must be a positive number.');
  if (!Array.isArray(config.metrics) || config.metrics.length === 0) throw new Error('Select at least one evaluation metric.');
  const supportedMetrics = new Set(['retrieval', 'correctness', 'citations', 'unsupported']);
  if (config.metrics.some(key => !supportedMetrics.has(key))) throw new Error('Configuration contains an unsupported evaluation metric.');
  const ids = new Set<string>();
  for (const c of cases) {
    if (!c.id?.trim() || !c.question?.trim()) throw new Error('Each test case requires a non-empty id and question.');
    if (ids.has(c.id)) throw new Error(`Duplicate test case ID: ${c.id}.`);
    ids.add(c.id);
    if (!Array.isArray(c.retrieved_contexts)) throw new Error(`Test case ${c.id}: retrieved_contexts must be an array.`);
    const contextIds = new Set<string>();
    for (const ctx of c.retrieved_contexts) {
      if (!ctx.id?.trim() || typeof ctx.text !== 'string') throw new Error(`Test case ${c.id}: each context needs a non-empty ID and string text.`);
      if (contextIds.has(ctx.id)) throw new Error(`Test case ${c.id}: duplicate context ID ${ctx.id}.`);
      contextIds.add(ctx.id);
    }
  }
  return cases.map(c => evaluateCase(c, config));
}

export function fingerprintDataset(cases: TestCase[]): string {
  const serialized = JSON.stringify(cases);
  let hash = 2166136261;
  for (let i = 0; i < serialized.length; i++) { hash ^= serialized.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return `fnv1a-${(hash >>> 0).toString(16)}-${serialized.length}`;
}

export type RunCompatibility = { dataset: boolean; metrics: boolean; cutoff: boolean; citationPolicy: boolean; compatible: boolean };
export function compareRunCompatibility(a: Run, b: Run): RunCompatibility {
  const dataset = a.datasetFingerprint && b.datasetFingerprint
    ? a.datasetFingerprint === b.datasetFingerprint
    : a.datasetId === b.datasetId && JSON.stringify(a.caseIds) === JSON.stringify(b.caseIds);
  const metrics = JSON.stringify([...a.config.metrics].sort()) === JSON.stringify([...b.config.metrics].sort());
  const cutoff = a.config.k === b.config.k;
  const citationPolicy = a.config.requireCitations === b.config.requireCitations;
  return { dataset: Boolean(dataset), metrics, cutoff, citationPolicy, compatible: Boolean(dataset) && metrics && cutoff && citationPolicy };
}

export function evaluateCounterfactual(cases: TestCase[], config: EvalConfig, caseId: string, changes: Partial<Pick<EvalConfig, 'k' | 'requireCitations' | 'metrics'>>): { baseline: CaseResult; candidate: CaseResult; candidateConfig: EvalConfig; changedVariables: string[] } {
  const selected = cases.find(c => c.id === caseId);
  if (!selected) throw new Error(`Case ${caseId} was not found in the selected dataset.`);
  const baselineConfig = { ...config, metrics: [...config.metrics] };
  const candidateConfig: EvalConfig = { ...config, ...changes, metrics: changes.metrics ? [...changes.metrics] : [...config.metrics] };
  const baseline = evaluateCase(selected, baselineConfig);
  const candidate = evaluateCase(selected, candidateConfig);
  const changedVariables = (['k', 'requireCitations', 'metrics'] as const).filter(key => JSON.stringify(baselineConfig[key]) !== JSON.stringify(candidateConfig[key]));
  return { baseline, candidate, candidateConfig, changedVariables };
}

export function makeRun(name: string, datasetId: string, datasetName: string, cases: TestCase[], config: EvalConfig, sample = false): Run {
  const normalizedConfig = { ...config, k: Math.floor(config.k), metrics: [...new Set(config.metrics)] };
  const datasetFingerprint = fingerprintDataset(cases);
  return { id: `run-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`, name, timestamp: new Date().toISOString(), datasetId, datasetName, config: normalizedConfig, results: evaluateDataset(cases, normalizedConfig), sample, caseIds: cases.map(c => c.id), datasetFingerprint };
}

export function aggregate(results: CaseResult[], key: 'retrieval' | 'correctness' | 'citations' | 'unsupported'): number | null {
  const vals = results.map(r => r[key].score).filter((x): x is number => x !== null && Number.isFinite(x));
  return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
}
