import { describe, it, expect } from 'vitest';
import { parseDataset, validateDataset } from './io';

describe('dataset import and preview validation', () => {
  it('parses JSON arrays and reports reference/label coverage', () => {
    const ds = parseDataset(JSON.stringify([{ id: 'A', question: 'Question?', generated_answer: 'Answer', reference_answer: 'Answer', retrieved_contexts: [{ id: 'ctx-a', text: 'Answer', relevant: true }] }]), 'sample.json');
    const result = validateDataset(ds);
    expect(result.caseCount).toBe(1);
    expect(result.referenceAnswerCoverage).toBe(1);
    expect(result.relevanceLabelCoverage).toBe(1);
    expect(result.errors).toHaveLength(0);
    expect(result.contextCount).toBe(1);
    expect(result.emptyContextTextCount).toBe(0);
  });

  it('detects duplicate case and context IDs as structural errors', () => {
    const ds = parseDataset(JSON.stringify([
      { id: 'DUP', question: 'First?', retrieved_contexts: [{ id: 'same', text: 'One' }] },
      { id: 'DUP', question: 'Second?', retrieved_contexts: [{ id: 'same', text: 'Two' }] }
    ]), 'duplicates.json');
    const result = validateDataset(ds);
    expect(result.duplicateCaseIds).toContain('DUP');
    expect(result.duplicateContextIds).toContain('DUP/same');
    expect(result.errors.length).toBeGreaterThanOrEqual(2);
  });

  it('warns when expected evidence and citations do not resolve', () => {
    const ds = parseDataset(JSON.stringify([{
      id: 'C1', question: 'Question?', generated_answer: 'Answer',
      retrieved_contexts: [{ id: 'ctx-1', text: 'Evidence' }],
      expected_evidence: ['missing-evidence'], citations: [{ context_id: 'missing-citation', claim: 'Claim' }]
    }]), 'bad-links.json');
    const result = validateDataset(ds);
    expect(result.warnings.some(x => x.code === 'missing-expected-evidence')).toBe(true);
    expect(result.warnings.some(x => x.code === 'invalid-citation')).toBe(true);
  });

  it('rejects malformed JSONL with a line-specific message', () => {
    expect(() => parseDataset('{bad}\n', 'bad.jsonl')).toThrow(/line 1/i);
  });

  it('rejects an empty dataset', () => {
    expect(() => parseDataset('[]', 'empty.json')).toThrow(/No test cases/i);
  });
});


describe('strict input validation',()=>{
  it('rejects malformed CSV quoting instead of silently accepting it',()=>{
    expect(()=>parseDataset('id,question\nA,\"unterminated','bad.csv')).toThrow(/unterminated quoted field/i);
  });
  it('rejects CSV rows with extra or missing fields',()=>{
    expect(()=>parseDataset('id,question\nA,Q?,extra','bad.csv')).toThrow(/expected 2/i);
  });
  it('accepts plain-text context cells in CSV',()=>{
    const ds=parseDataset('id,question,generated_answer,retrieved_contexts\nA,What is it?,It is a thing,The answer is here','plain.csv');
    expect(ds.cases[0].retrieved_contexts).toEqual([{id:'ctx-1',text:'The answer is here'}]);
  });
  it('rejects malformed expected evidence and citation shapes',()=>{
    expect(()=>parseDataset(JSON.stringify([{id:'A',question:'Q?',expected_evidence:[42]}]),'bad.json')).toThrow(/expected_evidence must be an array/i);
    expect(()=>parseDataset(JSON.stringify([{id:'A',question:'Q?',citations:[{claim:'no context id'}]}]),'bad.json')).toThrow(/citation 1 needs/i);
  });
  it('warns about empty context text and reports context totals',()=>{
    const ds=parseDataset(JSON.stringify([{id:'A',question:'Q?',retrieved_contexts:[{id:'ctx',text:''}]}]),'empty-context.json');
    const result=validateDataset(ds);
    expect(result.contextCount).toBe(1);
    expect(result.emptyContextTextCount).toBe(1);
    expect(result.warnings.some(x=>x.code==='empty-context-text')).toBe(true);
  });
});
