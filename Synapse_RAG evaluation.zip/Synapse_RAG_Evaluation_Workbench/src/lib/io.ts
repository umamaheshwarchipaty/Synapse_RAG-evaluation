import type {Dataset,TestCase,Run} from '../types';
export function parseDataset(text: string, filename: string): Dataset {
  const ext = filename.toLowerCase().split('.').pop();
  let raw: unknown[];
  try {
    if (ext === 'jsonl') {
      raw = text.split(/\r?\n/).filter(line => line.trim()).map((line, index) => {
        try { return JSON.parse(line) as unknown; }
        catch { throw new Error(`Invalid JSONL on line ${index + 1}.`); }
      });
    } else if (ext === 'csv') {
      const rows = parseCSV(text);
      if (rows.length < 2) throw new Error('CSV must include a header and at least one data row.');
      const headers = rows[0].map(value => value.trim());
      if (headers.some(header => !header)) throw new Error('CSV headers must not be empty.');
      if (new Set(headers).size !== headers.length) throw new Error('CSV contains duplicate column headers.');
      raw = rows.slice(1).filter(row => row.some(Boolean)).map((row, index) => {
        if (row.length !== headers.length) throw new Error(`CSV row ${index + 2} has ${row.length} field(s); expected ${headers.length}.`);
        const item: Record<string, unknown> = {};
        headers.forEach((header, column) => { item[header] = row[column] ?? ''; });
        for (const key of ['retrieved_contexts', 'expected_evidence', 'citations'] as const) {
          const value = item[key];
          if (typeof value !== 'string' || !value.trim()) continue;
          try { item[key] = JSON.parse(value) as unknown; }
          catch (error) {
            if (key === 'retrieved_contexts') item[key] = [{ id: `ctx-${index + 1}`, text: value }];
            else throw new Error(`CSV row ${index + 2}: ${key} must contain valid JSON.`);
          }
        }
        if (typeof item.retrieved_contexts === 'string') item.retrieved_contexts = [{ id: `ctx-${index + 1}`, text: item.retrieved_contexts }];
        return item;
      });
    } else {
      const parsed: unknown = JSON.parse(text);
      raw = Array.isArray(parsed) ? parsed : parsed && typeof parsed === 'object' && Array.isArray((parsed as { cases?: unknown[] }).cases) ? (parsed as { cases: unknown[] }).cases : [];
    }
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : 'Could not parse dataset.');
  }
  if (!raw.length) throw new Error('No test cases found. JSON must be an array or an object with a cases array.');
  const cases: TestCase[] = raw.map((value, index) => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`Row ${index + 1} must be an object.`);
    const item = value as Record<string, unknown>;
    if (typeof item.id !== 'string' || !item.id.trim()) throw new Error(`Row ${index + 1}: id is required as a string.`);
    const id = item.id;
    if (typeof item.question !== 'string' || !item.question.trim()) throw new Error(`${id}: question is required as a string.`);
    if (item.retrieved_contexts !== undefined && !Array.isArray(item.retrieved_contexts)) throw new Error(`${id}: retrieved_contexts must be an array.`);
    const contexts = ((item.retrieved_contexts ?? []) as unknown[]).map((context, contextIndex) => {
      if (!context || typeof context !== 'object' || Array.isArray(context)) throw new Error(`${id}: context ${contextIndex + 1} must be an object.`);
      const ctx = context as Record<string, unknown>;
      if (typeof ctx.id !== 'string' || !ctx.id.trim() || typeof ctx.text !== 'string') throw new Error(`${id}: context ${contextIndex + 1} needs a non-empty string id and string text.`);
      if (ctx.relevant !== undefined && typeof ctx.relevant !== 'boolean') throw new Error(`${id}: context ${contextIndex + 1} relevance label must be true or false.`);
      return { id: ctx.id, text: ctx.text, ...(typeof ctx.relevant === 'boolean' ? { relevant: ctx.relevant } : {}) };
    });
    if (item.generated_answer !== undefined && typeof item.generated_answer !== 'string') throw new Error(`${id}: generated_answer must be a string when supplied.`);
    if (item.reference_answer !== undefined && typeof item.reference_answer !== 'string') throw new Error(`${id}: reference_answer must be a string when supplied.`);
    if (item.expected_evidence !== undefined && (!Array.isArray(item.expected_evidence) || !item.expected_evidence.every((evidence: unknown) => typeof evidence === 'string' && evidence.trim()))) throw new Error(`${id}: expected_evidence must be an array of non-empty strings.`);
    if (item.citations !== undefined && !Array.isArray(item.citations)) throw new Error(`${id}: citations must be an array.`);
    const citations = ((item.citations ?? []) as unknown[]).map((citation, citationIndex) => {
      if (!citation || typeof citation !== 'object' || Array.isArray(citation)) throw new Error(`${id}: citation ${citationIndex + 1} must be an object.`);
      const cite = citation as Record<string, unknown>;
      if (typeof cite.context_id !== 'string' || !cite.context_id.trim() || (cite.claim !== undefined && typeof cite.claim !== 'string')) throw new Error(`${id}: citation ${citationIndex + 1} needs a context_id string and optional string claim.`);
      return { context_id: cite.context_id, ...(typeof cite.claim === 'string' ? { claim: cite.claim } : {}) };
    });
    return {
      id, question: item.question, retrieved_contexts: contexts,
      generated_answer: typeof item.generated_answer === 'string' ? item.generated_answer : '',
      ...(typeof item.reference_answer === 'string' ? { reference_answer: item.reference_answer } : {}),
      ...(Array.isArray(item.expected_evidence) ? { expected_evidence: item.expected_evidence as string[] } : {}),
      citations
    };
  });
  return { id: `dataset-${Date.now()}`, name: filename.replace(/\.(jsonl?|csv)$/i, ''), cases };
}

function parseCSV(text: string): string[][] {
  const output: string[][] = [];
  let row: string[] = [], cell = '', quoted = false, fieldStarted = false;
  for (let index = 0; index < text.length; index++) {
    const char = text[index];
    if (char === '"' && quoted && text[index + 1] === '"') { cell += '"'; index++; }
    else if (char === '"') {
      if (!quoted && fieldStarted) throw new Error(`Malformed CSV: unexpected quote near character ${index + 1}.`);
      quoted = !quoted; fieldStarted = true;
    } else if (char === ',' && !quoted) { row.push(cell); cell = ''; fieldStarted = false; }
    else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && text[index + 1] === '\n') index++;
      row.push(cell); output.push(row); row = []; cell = ''; fieldStarted = false;
    } else { cell += char; fieldStarted = true; }
  }
  if (quoted) throw new Error('Malformed CSV: unterminated quoted field.');
  if (cell || row.length) { row.push(cell); output.push(row); }
  return output;
}
export function download(name:string,content:string,type='application/json'){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
export function reportMarkdown(run:Run){return `# ${run.name}\n\n- Run ID: ${run.id}\n- Timestamp: ${run.timestamp}\n- Dataset: ${run.datasetName} (${run.datasetId})\n- Configuration: k=${run.config.k}; citations required=${run.config.requireCitations}; metrics=${run.config.metrics.join(', ')}\n- Sample data: ${run.sample?'Yes — illustrative sample':'No'}\n- Dataset fingerprint: ${run.datasetFingerprint ?? 'Unavailable for this legacy saved run'}\n\n## Methodology\n- Retrieval relevance: precision@k when labels exist, otherwise expected-evidence coverage when supplied.\n- Answer correctness: normalized token-overlap F1 against reference answer; lexical similarity is not factual verification.\n- Citation accuracy: citation ID resolution; valid IDs do not prove semantic claim support.\n- Unsupported answer: heuristic lexical overlap against retrieved context; not an LLM or human grounding verdict.\n\n## Case results\n${run.results.map(r=>`### ${r.caseId}\n- Retrieval: ${r.retrieval.score===null?'N/A':(r.retrieval.score*100).toFixed(1)+'%'} — ${r.retrieval.explanation}\n- Correctness: ${r.correctness.score===null?'N/A':(r.correctness.score*100).toFixed(1)+'%'} — ${r.correctness.explanation}\n- Citation accuracy: ${r.citations.score===null?'N/A':(r.citations.score*100).toFixed(1)+'%'} — ${r.citations.explanation}\n- Unsupported flag: ${r.unsupported.score===null?'N/A':r.unsupported.score?'Flagged':'Not flagged'} — ${r.unsupported.explanation}\n- Failures: ${r.failures.join(', ')||'None detected'}\n- Diagnosis: ${r.diagnosis}\n- Suggested action: ${r.suggestedAction}\n${(r.findings??[]).length ? `\n#### Evidence-linked findings\n${(r.findings??[]).map(f=>`- **${f.category}** (${f.severity}; ${f.method}) — ${f.summary}\n  - Basis: ${f.basis}\n  - Evidence IDs: ${f.evidenceIds.join(', ')||'None linked'}\n  - Next step: ${f.nextStep}`).join('\n')}` : '\nNo structured finding was triggered by the configured deterministic rules.'}`).join('\n\n')}\n\n## Limitations\nThese deterministic heuristics do not establish semantic entailment or factual truth. Review claim-to-evidence links manually. Missing labels and reference answers remain unavailable, not imputed.`}


export type DatasetValidationIssue = {
  severity: 'error' | 'warning' | 'info';
  code: string;
  message: string;
  caseId?: string;
};

export type DatasetValidationSummary = {
  caseCount: number;
  errors: DatasetValidationIssue[];
  warnings: DatasetValidationIssue[];
  info: DatasetValidationIssue[];
  duplicateCaseIds: string[];
  duplicateContextIds: string[];
  relevanceLabelCoverage: number;
  referenceAnswerCoverage: number;
  contextCount: number;
  emptyContextTextCount: number;
};

/** Validate the parsed dataset without mutating or silently dropping any case. */
export function validateDataset(dataset: Dataset): DatasetValidationSummary {
  const errors: DatasetValidationIssue[] = [];
  const warnings: DatasetValidationIssue[] = [];
  const info: DatasetValidationIssue[] = [];
  const caseCounts = new Map<string, number>();
  const duplicateContextIds: string[] = [];
  dataset.cases.forEach(c => {
    caseCounts.set(c.id, (caseCounts.get(c.id) ?? 0) + 1);
    const localCounts = new Map<string, number>();
    c.retrieved_contexts.forEach(ctx => localCounts.set(ctx.id, (localCounts.get(ctx.id) ?? 0) + 1));
    localCounts.forEach((count, id) => {
      if (count > 1) {
        duplicateContextIds.push(`${c.id}/${id}`);
        errors.push({ severity: 'error', code: 'duplicate-context-id', message: `Context ID "${id}" is repeated within case "${c.id}". Evidence links may resolve ambiguously.`, caseId: c.id });
      }
    });
  });
  const duplicateCaseIds = [...caseCounts].filter(([, count]) => count > 1).map(([id]) => id);
  duplicateCaseIds.forEach(id => errors.push({ severity: 'error', code: 'duplicate-case-id', message: `Duplicate case ID "${id}". Case IDs must be unique.`, caseId: id }));
  dataset.cases.forEach(c => {
    if (!c.question.trim()) errors.push({ severity: 'error', code: 'empty-question', message: 'Question is empty.', caseId: c.id });
    if (!c.generated_answer.trim()) warnings.push({ severity: 'warning', code: 'empty-answer', message: 'Generated answer is empty; answer-based metrics may be unavailable or fail.', caseId: c.id });
    if (!c.retrieved_contexts.length) warnings.push({ severity: 'warning', code: 'no-contexts', message: 'No retrieved contexts supplied.', caseId: c.id });
    if (!c.reference_answer?.trim()) info.push({ severity: 'info', code: 'missing-reference', message: 'No reference answer; lexical correctness will be unavailable.', caseId: c.id });
    const known = new Set(c.retrieved_contexts.map(ctx => ctx.id));
    (c.expected_evidence ?? []).filter(id => !known.has(id)).forEach(id => warnings.push({ severity: 'warning', code: 'missing-expected-evidence', message: `Expected evidence ID "${id}" is not present in this case's retrieved contexts.`, caseId: c.id }));
    (c.citations ?? []).filter(cite => !known.has(cite.context_id)).forEach(cite => warnings.push({ severity: 'warning', code: 'invalid-citation', message: `Citation ID "${cite.context_id}" does not resolve to a retrieved context.`, caseId: c.id }));
    if (!c.retrieved_contexts.some(ctx => typeof ctx.relevant === 'boolean') && !(c.expected_evidence?.length)) {
      info.push({ severity: 'info', code: 'no-retrieval-labels', message: 'No relevance labels or expected evidence; retrieval relevance will be unavailable.', caseId: c.id });
    }
  });
  const contexts = dataset.cases.flatMap(c => c.retrieved_contexts);
  const labeled = contexts.filter(c => typeof c.relevant === 'boolean').length;
  const relevanceLabelCoverage = contexts.length ? labeled / contexts.length : 0;
  const referenceAnswerCoverage = dataset.cases.length ? dataset.cases.filter(c => !!c.reference_answer?.trim()).length / dataset.cases.length : 0;
  if (dataset.cases.length === 0) errors.push({ severity: 'error', code: 'empty-dataset', message: 'Dataset contains no cases.' });
  if (!errors.length) info.push({ severity: 'info', code: 'valid-structure', message: 'No structural errors detected. Metric coverage limitations are listed separately.' });
  const emptyContextTextCount = contexts.filter(c => !c.text.trim()).length;
  if (emptyContextTextCount) warnings.push({ severity: 'warning', code: 'empty-context-text', message: `${emptyContextTextCount} retrieved context(s) have empty text; lexical grounding signals may be unavailable.` });
  return { caseCount: dataset.cases.length, errors, warnings, info, duplicateCaseIds, duplicateContextIds, relevanceLabelCoverage, referenceAnswerCoverage, contextCount: contexts.length, emptyContextTextCount };
}
