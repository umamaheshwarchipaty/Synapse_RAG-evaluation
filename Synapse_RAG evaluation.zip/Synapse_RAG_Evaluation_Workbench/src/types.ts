export type Citation = { context_id: string; claim?: string };
export type TestCase = {
  id: string;
  question: string;
  retrieved_contexts: { id: string; text: string; relevant?: boolean }[];
  generated_answer: string;
  reference_answer?: string;
  expected_evidence?: string[];
  citations?: Citation[];
  synthetic?: { strategy: string; difficulty: string; challenge: string; provenance: string; reviewStatus: 'approved'; expectedBehavior: 'answer' | 'abstain' };
};
export type MetricResult = {
  score: number | null;
  verdict: 'pass' | 'fail' | 'review' | 'unavailable';
  explanation: string;
  formula: string;
};
export type DiagnosticFinding = {
  id: string;
  category: string;
  severity: 'high' | 'medium' | 'low';
  summary: string;
  basis: string;
  evidenceIds: string[];
  method: 'deterministic' | 'heuristic';
  nextStep: string;
};
export type CaseResult = {
  caseId: string;
  retrieval: MetricResult;
  correctness: MetricResult;
  citations: MetricResult;
  unsupported: MetricResult;
  failures: string[];
  diagnosis: string;
  suggestedAction: string;
  findings?: DiagnosticFinding[];
};
export type EvalConfig = { name: string; k: number; requireCitations: boolean; metrics: string[] };
export type Run = {
  id: string;
  name: string;
  timestamp: string;
  datasetId: string;
  datasetName: string;
  config: EvalConfig;
  results: CaseResult[];
  sample: boolean;
  caseIds: string[];
  datasetFingerprint?: string;
};
export type Dataset = { id: string; name: string; cases: TestCase[]; sample?: boolean };
